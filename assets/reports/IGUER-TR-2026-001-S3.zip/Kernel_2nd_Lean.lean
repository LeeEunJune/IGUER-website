import Kernel_1st_Lean
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus

/-!
Kernel continuity consistency, Lean 4.19.0 / mathlib v4.19.0.
The kernel bandwidth is held constant during time differentiation.
Theorems about sums and derivatives are exact. Smoothing and sampling
assumptions are distinguished from the resulting consistency limits.
-/
namespace KernelContinuity
open KernelNetwork Finset Filter MeasureTheory
open scoped Topology Convolution

section TimeDerivatives
variable {ι E : Type*} [Fintype ι] [NormedAddCommGroup E] [NormedSpace ℝ E]

noncomputable def timeCrowd (W : E → ℝ) (x : ι → ℝ → E) (t : ℝ) (i : ι) : ℝ :=
  ∑ j, W (x i t-x j t)

/-- Actual moving-particle sum in any normed spatial dimension. -/
theorem time_crowd_derivative (W : E → ℝ) (x : ι → ℝ → E)
    (u : ι → E) (t : ℝ) (i : ι) (DW : ι → E →L[ℝ] ℝ)
    (hx : ∀ j, HasDerivAt (x j) (u j) t)
    (hW : ∀ j, HasFDerivAt W (DW j) (x i t-x j t)) :
    HasDerivAt (fun s => timeCrowd W x s i) (∑ j, DW j (u i-u j)) t := by
  apply HasDerivAt.sum
  intro j _
  exact (hW j).comp_hasDerivAt t ((hx i).sub (hx j))

theorem self_term_zero (D : E →L[ℝ] ℝ) (u : E) : D (u-u)=0 := by simp

end TimeDerivatives

noncomputable def weightSum {ι : Type*} [Fintype ι] (n : ι → ℝ → ℝ) (t : ℝ) : ℝ :=
  ∑ i, KernelNetwork.weight (n i t)

noncomputable def weightSumRate {ι : Type*} [Fintype ι]
    (n : ι → ℝ → ℝ) (dn : ι → ℝ) (t : ℝ) : ℝ :=
  ∑ i, -(KernelNetwork.weight (n i t))^2*dn i

noncomputable def particleVolume {ι : Type*} [Fintype ι]
    (n : ι → ℝ → ℝ) (L t : ℝ) (i : ι) : ℝ :=
  virtualVolume L (weightSum n t) (KernelNetwork.weight (n i t))

theorem weight_sum_derivative {ι : Type*} [Fintype ι] (n : ι → ℝ → ℝ)
    (dn : ι → ℝ) (t : ℝ) (hn : ∀ i, HasDerivAt (n i) (dn i) t)
    (hn0 : ∀ i, n i t ≠ 0) :
    HasDerivAt (weightSum n) (weightSumRate n dn t) t := by
  apply HasDerivAt.sum
  intro i _
  exact inverse_density_derivative (n i) t (dn i) (hn i) (hn0 i)

/-- Independent derivative of S, as a weighted sum of local expansion. -/
theorem weight_sum_rate_identity {ι : Type*} [Fintype ι]
    (n : ι → ℝ → ℝ) (dn : ι → ℝ) (t : ℝ) :
    weightSumRate n dn t = ∑ i, KernelNetwork.weight (n i t)*(-dn i/n i t) := by
  unfold weightSumRate KernelNetwork.weight
  apply sum_congr rfl
  intro i _
  ring

theorem volume_log_rate_algebra (L n dn S dS : ℝ)
    (hL : L ≠ 0) (hn : n ≠ 0) (hS : S ≠ 0) :
    (L*((-(1/n)^2*dn)*S-(1/n)*dS)/S^2)/virtualVolume L S (1/n) =
      -dn/n-dS/S := by
  unfold virtualVolume
  field_simp
  <;> ring

/-- Exact logarithmic derivative of the actual normalized particle volume. -/
theorem network_expansion_exact {ι : Type*} [Fintype ι]
    (n : ι → ℝ → ℝ) (dn : ι → ℝ) (L t : ℝ) (i : ι)
    (hn : ∀ j, HasDerivAt (n j) (dn j) t) (hn0 : ∀ j, n j t ≠ 0)
    (hL : L ≠ 0) (hS : weightSum n t ≠ 0) :
    deriv (fun s => particleVolume n L s i) t / particleVolume n L t i =
      -dn i/n i t-weightSumRate n dn t/weightSum n t := by
  have hN := inverse_density_derivative (n i) t (dn i) (hn i) (hn0 i)
  have hsum := weight_sum_derivative n dn t hn hn0
  have hv := normalized_volume_derivative (fun s => KernelNetwork.weight (n i s))
    (weightSum n) L t (-(KernelNetwork.weight (n i t))^2*dn i) (weightSumRate n dn t) hN hsum hS
  change deriv (fun s => virtualVolume L (weightSum n s) (KernelNetwork.weight (n i s))) t /
    virtualVolume L (weightSum n t) (KernelNetwork.weight (n i t)) = _
  rw [hv.deriv]
  exact volume_log_rate_algebra L (n i t) (dn i) (weightSum n t) (weightSumRate n dn t) hL (hn0 i) hS

theorem constant_mass_density_derivative (V : ℝ → ℝ) (m t dV : ℝ)
    (hV : HasDerivAt V dV t) (hV0 : V t ≠ 0) :
    HasDerivAt (fun s => m/V s) (-(m/V t)*(dV/V t)) t := by
  convert (hasDerivAt_const t m).div hV hV0 using 1 <;> field_simp [hV0] <;> ring <;> simp_all

/-- The density relation concerns actual time derivatives, not a symbolic substitution. -/
theorem exact_discrete_density (V : ℝ → ℝ) (m t dV : ℝ)
    (hV : HasDerivAt V dV t) (hV0 : V t ≠ 0) :
    deriv (fun s => m/V s) t = -(m/V t)*(deriv V t/V t) := by
  rw [(constant_mass_density_derivative V m t dV hV hV0).deriv, hV.deriv]

/-- With fixed cardinality and nonzero normalization, total volume remains L. -/
theorem total_particle_volume {ι : Type*} [Fintype ι] (n : ι → ℝ → ℝ) (L t : ℝ)
    (hS : weightSum n t ≠ 0) : (∑ i, particleVolume n L t i) = L := by
  exact total_volume (fun i => KernelNetwork.weight (n i t)) L hS

/-- Periodic one-dimensional divergence has zero integral by FTC. -/
theorem periodic_divergence_integral (u : ℝ → ℝ) (a b : ℝ)
    (hu : ∀ x ∈ Set.uIcc a b, DifferentiableAt ℝ u x)
    (hi : IntervalIntegrable (deriv u) volume a b) (hperiod : u b=u a) :
    (∫ x in a..b, deriv u x)=0 := by
  rw [intervalIntegral.integral_deriv_eq_sub hu hi, hperiod, sub_self]

/-- Kernel velocity-difference integral before differentiation is moved off the kernel. -/
theorem velocity_commutator_integral (K f u : ℝ → ℝ) (x : ℝ)
    (h1 : Integrable (fun y => K y*f (x-y)))
    (h2 : Integrable (fun y => K y*(f (x-y)*u (x-y)))) :
    (∫ y, K y*(u x-u (x-y))*f (x-y)) =
      u x*(∫ y, K y*f (x-y))-(∫ y, K y*(f (x-y)*u (x-y))) := by
  have he : ∀ y, K y*(u x-u (x-y))*f (x-y) =
      u x*(K y*f (x-y))-K y*(f (x-y)*u (x-y)) := by intro y; ring
  simp_rw [he]
  rw [integral_sub (h1.const_mul (u x)) h2, integral_const_mul]

/-- No continuity PDE for f is assumed: this is only the spatial product rule. -/
theorem flux_product_rule (f u : ℝ → ℝ) (x df du : ℝ)
    (hf : HasDerivAt f df x) (hu : HasDerivAt u du x) :
    deriv (fun y => f y*u y) x = u x*df+f x*du := by
  rw [(hf.mul hu).deriv]
  ring

end KernelContinuity

namespace KernelContinuity
open KernelNetwork Finset Filter MeasureTheory Function
open scoped Topology Convolution

/-- An explicit local error estimate from three independently measurable
    smoothing errors. No continuity equation for f appears in its assumptions. -/
theorem local_rate_error_bound (r B C f df u d c eR eB eC U D : ℝ)
    (hc : 0 < c) (hr : c ≤ r)
    (hR : |r-f| ≤ eR) (hB : |B-df| ≤ eB)
    (hC : |C-(u*df+f*d)| ≤ eC) (hu : |u| ≤ U) (hd : |d| ≤ D)
    (heR : 0 ≤ eR) (heB : 0 ≤ eB) (heC : 0 ≤ eC) :
    |(C-u*B)/r-d| ≤ (eC+U*eB+D*eR)/c := by
  have hrpos : 0 < r := lt_of_lt_of_le hc hr
  have hU : 0 ≤ U := le_trans (abs_nonneg _) hu
  have hD : 0 ≤ D := le_trans (abs_nonneg _) hd
  have heq : (C-u*B)/r-d = ((C-(u*df+f*d))+(-u*(B-df))+(-d*(r-f)))/r := by
    field_simp
    <;> ring
  have hn : |(C-(u*df+f*d))+(-u*(B-df))+(-d*(r-f))| ≤ eC+U*eB+D*eR := by
    calc
      _ ≤ |C-(u*df+f*d)|+|-u*(B-df)|+|-d*(r-f)| :=
        le_trans (abs_add _ _) (add_le_add_right (abs_add _ _) _)
      _ ≤ eC+U*eB+D*eR := by
        simp only [abs_mul, abs_neg]
        exact add_le_add (add_le_add hC (mul_le_mul hu hB (abs_nonneg _) hU))
          (mul_le_mul hd hR (abs_nonneg _) hD)
  rw [heq, abs_div, abs_of_pos hrpos]
  exact le_trans (div_le_div_of_nonneg_right hn hrpos.le)
    (div_le_div_of_nonneg_left (by positivity) hc hr)

/-- The actual commutator local rate converges to div u by approximate
    identities and the spatial product rule, not by assuming f_t+div(fu)=0. -/
theorem local_crowding_integral_limit {G I : Type*} [SeminormedAddCommGroup G]
    [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
    {μ : Measure G} [μ.IsAddLeftInvariant] [SFinite μ] {l : Filter I}
    (φ : I → G → ℝ) (f df flux : G → ℝ) (x : G) (u d : ℝ)
    (hf0 : f x ≠ 0) (hproduct : flux x=u*df x+f x*d)
    (hpos : ∀ᶠ i in l, ∀ y, 0 ≤ φ i y)
    (hmass : ∀ᶠ i in l, ∫ y, φ i y ∂μ=1)
    (hsupport : Tendsto (fun i => support (φ i)) l (𝓝 0).smallSets)
    (hmf : AEStronglyMeasurable f μ) (hmdf : AEStronglyMeasurable df μ)
    (hmflux : AEStronglyMeasurable flux μ)
    (hcf : ContinuousAt f x) (hcdf : ContinuousAt df x) (hcflux : ContinuousAt flux x) :
    Tendsto (fun i => (((φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] flux) x)-
      u*((φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] df) x))/
      ((φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] f) x)) l (𝓝 d) := by
  have hrf := approximate_identity_limit φ (fun _ => f) x (f x) hpos hmass hsupport
    (Eventually.of_forall fun _ => hmf) (hcf.tendsto.comp tendsto_snd)
  have hrd := approximate_identity_limit φ (fun _ => df) x (df x) hpos hmass hsupport
    (Eventually.of_forall fun _ => hmdf) (hcdf.tendsto.comp tendsto_snd)
  have hrc := approximate_identity_limit φ (fun _ => flux) x (flux x) hpos hmass hsupport
    (Eventually.of_forall fun _ => hmflux) (hcflux.tendsto.comp tendsto_snd)
  have hh := (hrc.sub (hrd.const_mul u)).div hrf hf0
  convert hh using 1
  congr 1
  rw [hproduct]
  field_simp
  <;> ring

/-- Quantitative independent normalization-derivative estimate. -/
theorem global_integrand_error_bound (f r A d η ε D : ℝ)
    (hf : 0 < f) (hr : 0 < r) (hη : 0 ≤ η) (hη1 : η < 1)
    (hrel : |r-f| ≤ η*f) (hA : |A-d| ≤ ε) (hd : |d| ≤ D) (hε : 0 ≤ ε) :
    |f/r*A-d| ≤ (ε+η*D)/(1-η) := by
  have hden : 0 < 1-η := by linarith
  have hD : 0 ≤ D := le_trans (abs_nonneg _) hd
  have hratio := relative_reciprocal_bound f r η hf hr hη hη1 hrel
  have hrlow : f*(1-η) ≤ r := by have := (abs_le.mp hrel).1; nlinarith
  have hrat : f/r ≤ 1/(1-η) := (div_le_div_iff₀ hr hden).2 (by nlinarith)
  have hratpos : 0 ≤ f/r := (div_pos hf hr).le
  have he : f/r*A-d = f/r*(A-d)+(f/r-1)*d := by ring
  rw [he]
  calc
    _ ≤ |f/r*(A-d)|+|(f/r-1)*d| := abs_add _ _
    _ ≤ (1/(1-η))*ε+(η/(1-η))*D := by
      rw [abs_mul, abs_mul, abs_of_nonneg hratpos]
      exact add_le_add (mul_le_mul hrat hA (abs_nonneg _) (by positivity))
        (mul_le_mul hratio hd (abs_nonneg _) (by positivity))
    _ = (ε+η*D)/(1-η) := by ring

/-- H_h is the independently derived limit of dot S, not the derivative of
    a previously established convergence statement for S. -/
theorem global_normalization_derivative_bound {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (f r A d : Ω → ℝ) (η ε D : ℝ)
    (hf : ∀ x, 0 < f x) (hr : ∀ x, 0 < r x)
    (hη : 0 ≤ η) (hη1 : η < 1) (hε : 0 ≤ ε)
    (hrel : ∀ x, |r x-f x| ≤ η*f x)
    (hA : ∀ x, |A x-d x| ≤ ε) (hd : ∀ x, |d x| ≤ D)
    (hi : Integrable (fun x => f x/r x*A x) μ) (hdi : Integrable d μ)
    (hboundary : ∫ x, d x ∂μ=0) :
    |∫ x, f x/r x*A x ∂μ| ≤ ((ε+η*D)/(1-η))*μ.real Set.univ := by
  have he : (∫ x, f x/r x*A x ∂μ) = ∫ x, (f x/r x*A x-d x) ∂μ := by
    rw [integral_sub hi hdi, hboundary, sub_zero]
  rw [he, ← Real.norm_eq_abs]
  exact norm_integral_le_of_norm_le_const (Eventually.of_forall fun x => by
    simpa only [Real.norm_eq_abs] using global_integrand_error_bound (f x) (r x) (A x) (d x) η ε D
      (hf x) (hr x) hη hη1 (hrel x) (hA x) (hd x) hε)

theorem global_normalization_derivative_limit {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (f d : Ω → ℝ) (r A : ℕ → Ω → ℝ)
    (η ε : ℕ → ℝ) (D : ℝ)
    (hf : ∀ x, 0 < f x) (hr : ∀ n x, 0 < r n x)
    (hη : ∀ n, 0 ≤ η n) (hη1 : ∀ n, η n < 1) (hε : ∀ n, 0 ≤ ε n)
    (hrel : ∀ n x, |r n x-f x| ≤ η n*f x)
    (hA : ∀ n x, |A n x-d x| ≤ ε n) (hd : ∀ x, |d x| ≤ D)
    (hi : ∀ n, Integrable (fun x => f x/r n x*A n x) μ) (hdi : Integrable d μ)
    (hboundary : ∫ x, d x ∂μ=0)
    (hηlim : Tendsto η atTop (𝓝 0)) (hεlim : Tendsto ε atTop (𝓝 0)) :
    Tendsto (fun n => ∫ x, f x/r n x*A n x ∂μ) atTop (𝓝 0) := by
  apply (tendsto_zero_iff_abs_tendsto_zero _).mpr
  apply squeeze_zero (fun _ => abs_nonneg _) (fun n =>
    global_normalization_derivative_bound μ f (r n) (A n) d (η n) (ε n) D hf (hr n)
      (hη n) (hη1 n) (hε n) (hrel n) (hA n) hd (hi n) hdi hboundary)
  simpa using ((hεlim.add (hηlim.mul_const D)).div
    ((tendsto_const_nhds (x := (1:ℝ))).sub hηlim) (by norm_num)).mul_const (μ.real Set.univ)

/-- Exact S-normalization and its independent derivative estimate combined. -/
theorem global_rate_integral_limit {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (f d : Ω → ℝ) (r A : ℕ → Ω → ℝ)
    (η ε : ℕ → ℝ) (D : ℝ) (hL : 0 < μ.real Set.univ)
    (hf : ∀ x, 0 < f x) (hr : ∀ n x, 0 < r n x)
    (hη : ∀ n, 0 ≤ η n) (hη1 : ∀ n, η n < 1) (hε : ∀ n, 0 ≤ ε n)
    (hrel : ∀ n x, |r n x-f x| ≤ η n*f x)
    (hA : ∀ n x, |A n x-d x| ≤ ε n) (hd : ∀ x, |d x| ≤ D)
    (hiS : ∀ n, Integrable (fun x => f x/r n x) μ)
    (hiH : ∀ n, Integrable (fun x => f x/r n x*A n x) μ)
    (hdi : Integrable d μ) (hboundary : ∫ x, d x ∂μ=0)
    (hηlim : Tendsto η atTop (𝓝 0)) (hεlim : Tendsto ε atTop (𝓝 0)) :
    Tendsto (fun n => (∫ x, f x/r n x*A n x ∂μ)/(∫ x, f x/r n x ∂μ)) atTop (𝓝 0) := by
  have hS := KernelNetwork.normalization_limit μ f r η hf hr hη hη1 hrel hiS hηlim
  have hH := global_normalization_derivative_limit μ f d r A η ε D hf hr hη hη1 hε
    hrel hA hd hiH hdi hboundary hηlim hεlim
  simpa using hH.div hS (ne_of_gt hL)

end KernelContinuity


namespace KernelContinuity
open KernelNetwork Finset Filter MeasureTheory
open scoped Topology

/-- Explicit composition of the two limits: first particle quadrature at
    fixed bandwidth, then the approximate-identity bandwidth limit. -/
theorem sequential_expansion_consistency
    (S H A : ℕ → ℕ → ℝ) (s h a : ℕ → ℝ) (L d : ℝ)
    (hs0 : ∀ k, s k ≠ 0) (hL : L ≠ 0)
    (hSq : ∀ k, Tendsto (S k) atTop (𝓝 (s k)))
    (hHq : ∀ k, Tendsto (H k) atTop (𝓝 (h k)))
    (hAq : ∀ k, Tendsto (A k) atTop (𝓝 (a k)))
    (hS : Tendsto s atTop (𝓝 L)) (hH : Tendsto h atTop (𝓝 0))
    (hA : Tendsto a atTop (𝓝 d)) :
    (∀ k, Tendsto (fun n => H k n/S k n) atTop (𝓝 (h k/s k))) ∧
    Tendsto (fun k => h k/s k) atTop (𝓝 0) ∧
    (∀ k, Tendsto (fun n => A k n-H k n/S k n) atTop (𝓝 (a k-h k/s k))) ∧
    Tendsto (fun k => a k-h k/s k) atTop (𝓝 d) := by
  have hglobal : Tendsto (fun k => h k/s k) atTop (𝓝 0) := by simpa using hH.div hS hL
  exact ⟨fun k => (hHq k).div (hSq k) (hs0 k), hglobal,
    fun k => (hAq k).sub ((hHq k).div (hSq k) (hs0 k)), by simpa using hA.sub hglobal⟩

/-- Physical mass scaling and volume scaling, with n held fixed in time. -/
theorem scaled_volume_density_identity (n r S L M : ℝ) (hn : n ≠ 0)
    (hr : r ≠ 0) (hS : S ≠ 0) (hL : L ≠ 0) :
    n*virtualVolume L S (1/(n*r)) = L/(S*r) ∧
    (M/n)/virtualVolume L S (1/(n*r)) = M*S*r/L := by
  unfold virtualVolume
  constructor <;> field_simp <;> ring

theorem scaled_volume_density_limit {I : Type*} {l : Filter I}
    (S r : I → ℝ) (L f M : ℝ) (hL : L ≠ 0) (hf : f ≠ 0)
    (hS : Tendsto S l (𝓝 L)) (hr : Tendsto r l (𝓝 f)) :
    Tendsto (fun i => L/(S i*r i)) l (𝓝 (1/f)) ∧
    Tendsto (fun i => M*S i*r i/L) l (𝓝 (M*f)) := by
  constructor
  · convert (tendsto_const_nhds (x := L)).div (hS.mul hr) (mul_ne_zero hL hf) using 1
    congr 1
    field_simp
  · convert (((tendsto_const_nhds (x := M)).mul hS).mul hr).div_const L using 1
    congr 1
    field_simp
    <;> ring

/-- The limiting density time derivative is calculated from the exact
    discrete mass relation; its value is not assumed. -/
theorem material_density_rate_limit {I : Type*} {l : Filter I}
    (ρ expansion : I → ℝ) (ρ0 d : ℝ)
    (hρ : Tendsto ρ l (𝓝 ρ0)) (he : Tendsto expansion l (𝓝 d)) :
    Tendsto (fun i => -ρ i*expansion i) l (𝓝 (-ρ0*d)) := by
  simpa only [neg_mul] using (hρ.mul he).neg

/-- Genuine time-space chain rule for a moving sample in any normed dimension. -/
theorem material_chain_rule {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (ρ : ℝ × E → ℝ) (Dρ : (ℝ × E) →L[ℝ] ℝ) (x : ℝ → E)
    (t : ℝ) (u : E) (hρ : HasFDerivAt ρ Dρ (t,x t)) (hx : HasDerivAt x u t) :
    HasDerivAt (fun s => ρ (s,x s)) (Dρ (1,0)+Dρ (0,u)) t := by
  have hp : HasDerivAt (fun s => (s,x s)) (1,u) t := (hasDerivAt_id t).prod hx
  convert hρ.comp_hasDerivAt t hp using 1
  have he : ((1:ℝ),u)=(1,0)+(0,u) := by simp
  rw [he, map_add]

/-- Actual spatial product-rule divergence; the directions may be chosen
    as the standard coordinate basis in Euclidean space. -/
theorem flux_divergence_product {ι E : Type*} [Fintype ι]
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    (ρ : E → ℝ) (u : ι → E → ℝ) (Dρ : E →L[ℝ] ℝ)
    (Du : ι → E →L[ℝ] ℝ) (v : ι → E) (x : E)
    (hρ : HasFDerivAt ρ Dρ x) (hu : ∀ i, HasFDerivAt (u i) (Du i) x) :
    (∑ i, fderiv ℝ (fun y => ρ y*u i y) x (v i)) =
      (∑ i, u i x*Dρ (v i))+ρ x*(∑ i, Du i (v i)) := by
  have hi : ∀ i, fderiv ℝ (fun y => ρ y*u i y) x (v i) =
      u i x*Dρ (v i)+ρ x*Du i (v i) := by
    intro i
    rw [(hρ.mul (hu i)).fderiv]
    simp only [ContinuousLinearMap.add_apply, ContinuousLinearMap.smul_apply, smul_eq_mul]
    ring
  simp_rw [hi]
  rw [sum_add_distrib, ← mul_sum]

/-- Euler conservative form from the already-derived material balance and
    the independently proved product rule. -/
theorem euler_conservative_form (ρt advective ρ d fluxDiv : ℝ)
    (hmaterial : ρt+advective = -ρ*d)
    (hproduct : fluxDiv=advective+ρ*d) : ρt+fluxDiv=0 := by linarith

/-- A concrete one-dimensional material-density construction. J=X_q and
    dJ=U_q for a C² flow map; no continuity PDE is an input. -/
theorem flow_map_density (J : ℝ → ℝ) (M t Uq : ℝ)
    (hJ : HasDerivAt J Uq t) (hJ0 : J t ≠ 0) :
    HasDerivAt (fun s => M/J s) (-(M/J t)*(Uq/J t)) t :=
  constant_mass_density_derivative J M t Uq hJ hJ0

#print axioms time_crowd_derivative
#print axioms network_expansion_exact
#print axioms exact_discrete_density
#print axioms local_crowding_integral_limit
#print axioms local_rate_error_bound
#print axioms global_normalization_derivative_limit
#print axioms global_rate_integral_limit
#print axioms sequential_expansion_consistency
#print axioms scaled_volume_density_limit
#print axioms material_chain_rule
#print axioms flux_divergence_product
#print axioms euler_conservative_form
#print axioms flow_map_density
end KernelContinuity

namespace KernelContinuity
open KernelNetwork Finset Filter MeasureTheory Function
open scoped Topology Convolution

/-- Arbitrary-dimensional local consistency, with divergence expressed in
    coordinate directions. The only product identity is div(fu)=u·grad f+f div u. -/
theorem local_crowding_integral_limit_nd {G I ι : Type*} [Fintype ι]
    [SeminormedAddCommGroup G] [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
    {μ : Measure G} [μ.IsAddLeftInvariant] [SFinite μ] {l : Filter I}
    (φ : I → G → ℝ) (f flux : G → ℝ) (df : ι → G → ℝ)
    (x : G) (u du : ι → ℝ) (hf0 : f x ≠ 0)
    (hproduct : flux x=∑ j, (u j*df j x+f x*du j))
    (hpos : ∀ᶠ i in l, ∀ y, 0 ≤ φ i y)
    (hmass : ∀ᶠ i in l, ∫ y, φ i y ∂μ=1)
    (hsupport : Tendsto (fun i => support (φ i)) l (𝓝 0).smallSets)
    (hmf : AEStronglyMeasurable f μ) (hmflux : AEStronglyMeasurable flux μ)
    (hmdf : ∀ j, AEStronglyMeasurable (df j) μ)
    (hcf : ContinuousAt f x) (hcflux : ContinuousAt flux x) (hcdf : ∀ j, ContinuousAt (df j) x) :
    Tendsto (fun i => (((φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] flux) x)-
      (∑ j, u j*((φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] df j) x)))/
      ((φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] f) x)) l (𝓝 (∑ j, du j)) := by
  have hrf := approximate_identity_limit φ (fun _ => f) x (f x) hpos hmass hsupport
    (Eventually.of_forall fun _ => hmf) (hcf.tendsto.comp tendsto_snd)
  have hrc := approximate_identity_limit φ (fun _ => flux) x (flux x) hpos hmass hsupport
    (Eventually.of_forall fun _ => hmflux) (hcflux.tendsto.comp tendsto_snd)
  have hrd : ∀ j, Tendsto (fun i => u j*((φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] df j) x))
      l (𝓝 (u j*df j x)) := by
    intro j
    exact (approximate_identity_limit φ (fun _ => df j) x (df j x) hpos hmass hsupport
      (Eventually.of_forall fun _ => hmdf j) ((hcdf j).tendsto.comp tendsto_snd)).const_mul (u j)
  have hsum := tendsto_finset_sum (univ : Finset ι) (fun j _ => hrd j)
  convert (hrc.sub hsum).div hrf hf0 using 1
  congr 1
  rw [hproduct, sum_add_distrib, ← mul_sum]
  field_simp
  <;> ring

/-- Eliminates the uniform local-rate premise from the global error bound
    by constructing it from independent crowding and commutator errors. -/
theorem global_derivative_bound_from_smoothing {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (f df u d r B C : Ω → ℝ)
    (c η eR eB eC U D : ℝ) (hc : 0 < c) (hη : 0 ≤ η) (hη1 : η < 1)
    (heR : 0 ≤ eR) (heB : 0 ≤ eB) (heC : 0 ≤ eC) (hU : 0 ≤ U) (hD : 0 ≤ D)
    (hf : ∀ x, 0 < f x) (hr : ∀ x, c ≤ r x)
    (hrel : ∀ x, |r x-f x| ≤ η*f x)
    (hR : ∀ x, |r x-f x| ≤ eR) (hB : ∀ x, |B x-df x| ≤ eB)
    (hC : ∀ x, |C x-(u x*df x+f x*d x)| ≤ eC)
    (hu : ∀ x, |u x| ≤ U) (hd : ∀ x, |d x| ≤ D)
    (hi : Integrable (fun x => f x/r x*((C x-u x*B x)/r x)) μ)
    (hdi : Integrable d μ) (hboundary : ∫ x, d x ∂μ=0) :
    |∫ x, f x/r x*((C x-u x*B x)/r x) ∂μ| ≤
      ((((eC+U*eB+D*eR)/c)+η*D)/(1-η))*μ.real Set.univ := by
  apply global_normalization_derivative_bound μ f r (fun x => (C x-u x*B x)/r x)
    d η ((eC+U*eB+D*eR)/c) D hf (fun x => lt_of_lt_of_le hc (hr x)) hη hη1
  · positivity
  · exact hrel
  · intro x
    exact local_rate_error_bound (r x) (B x) (C x) (f x) (df x) (u x) (d x) c eR eB eC U D
      hc (hr x) (hR x) (hB x) (hC x) (hu x) (hd x) heR heB heC
  · exact hd
  · exact hi
  · exact hdi
  · exact hboundary

#print axioms local_crowding_integral_limit_nd
#print axioms global_derivative_bound_from_smoothing
end KernelContinuity


namespace KernelContinuity
open KernelNetwork Finset Filter MeasureTheory
open scoped Topology

/-- Periodic integration by parts proved directly from FTC; no boundary
    contribution is silently discarded. -/
theorem periodic_product_integral (a b da db : ℝ → ℝ) (L : ℝ)
    (ha : ∀ y ∈ Set.uIcc 0 L, HasDerivAt a (da y) y)
    (hb : ∀ y ∈ Set.uIcc 0 L, HasDerivAt b (db y) y)
    (hiA : IntervalIntegrable (fun y => da y*b y) volume 0 L)
    (hiB : IntervalIntegrable (fun y => a y*db y) volume 0 L)
    (hperiod : a L*b L=a 0*b 0) :
    (∫ y in (0 : ℝ)..L, da y*b y)+(∫ y in (0 : ℝ)..L, a y*db y)=0 := by
  have hh := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun y hy => (ha y hy).mul (hb y hy)) (hiA.add hiB)
  rw [intervalIntegral.integral_add hiA hiB, hperiod, sub_self] at hh
  exact hh

theorem periodic_kernel_gradient_transfer (W K f df : ℝ → ℝ) (x L : ℝ)
    (hW : ∀ y, HasDerivAt W (K y) y)
    (hf : ∀ y ∈ Set.uIcc 0 L, HasDerivAt f (df y) y)
    (hKint : IntervalIntegrable (fun y => K (x-y)*f y) volume 0 L)
    (hWint : IntervalIntegrable (fun y => W (x-y)*df y) volume 0 L)
    (hWperiod : W (x-L)=W x) (hfperiod : f L=f 0) :
    (∫ y in (0 : ℝ)..L, K (x-y)*f y)=(∫ y in (0 : ℝ)..L, W (x-y)*df y) := by
  have ha : ∀ y ∈ Set.uIcc 0 L, HasDerivAt (fun z => W (x-z)) (-K (x-y)) y := by
    intro y _
    simpa using (hW (x-y)).comp_of_eq y ((hasDerivAt_id y).const_sub x) (by rfl)
  have hneg : IntervalIntegrable (fun y => (-K (x-y))*f y) volume 0 L := by
    simpa only [neg_mul] using hKint.neg
  have hh := periodic_product_integral (fun y => W (x-y)) f (fun y => -K (x-y)) df L ha hf hneg hWint
    (by simpa only [hWperiod, hfperiod, sub_zero])
  simp only [neg_mul, intervalIntegral.integral_neg] at hh
  linarith

/-- A finite-sum estimate for dot S / S independently of any integral limit. -/
theorem finite_global_rate_bound {ι : Type*} [Fintype ι]
    (N A d : ι → ℝ) (ε Q : ℝ) (hN : ∀ i, 0 ≤ N i)
    (hS : 0 < ∑ i, N i) (hA : ∀ i, |A i-d i| ≤ ε)
    (hQ : |∑ i, N i*d i| ≤ Q) :
    |(∑ i, N i*A i)/(∑ i, N i)| ≤ ε+Q/(∑ i, N i) := by
  have he : (∑ i, N i*A i)=(∑ i, N i*(A i-d i))+(∑ i, N i*d i) := by
    rw [← sum_add_distrib]
    apply sum_congr rfl
    intro i _
    ring
  have hE : |∑ i, N i*(A i-d i)| ≤ ε*(∑ i, N i) := by
    calc
      _ ≤ ∑ i, |N i*(A i-d i)| := abs_sum_le_sum_abs _ _
      _ ≤ ∑ i, N i*ε := by
        apply sum_le_sum
        intro i _
        rw [abs_mul, abs_of_nonneg (hN i)]
        exact mul_le_mul_of_nonneg_left (hA i) (hN i)
      _ = ε*(∑ i, N i) := by rw [← sum_mul]; ring
  rw [abs_div, abs_of_pos hS]
  apply (div_le_iff₀ hS).2
  rw [he]
  calc
    _ ≤ |∑ i, N i*(A i-d i)|+|∑ i, N i*d i| := abs_add _ _
    _ ≤ ε*(∑ i, N i)+Q := add_le_add hE hQ
    _ = (ε+Q/(∑ i, N i))*(∑ i, N i) := by field_simp

#print axioms periodic_divergence_integral
#print axioms periodic_kernel_gradient_transfer
#print axioms finite_global_rate_bound
end KernelContinuity


namespace KernelContinuity
open KernelNetwork Finset Filter MeasureTheory Function
open scoped Topology Convolution

/-- Actual kernel-integral uniform error from a source-field modulus of
    continuity. Apply to f, partial derivatives of f, and div(fu). -/
theorem uniform_convolution_error {G : Type*} [SeminormedAddCommGroup G]
    [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
    {μ : Measure G} [μ.IsAddLeftInvariant] [SFinite μ]
    (W g : G → ℝ) (R ε : ℝ) (hε : 0 ≤ ε)
    (hpos : ∀ y, 0 ≤ W y) (hmass : ∫ y, W y ∂μ=1)
    (hsupport : support W ⊆ Metric.ball 0 R) (hmg : AEStronglyMeasurable g μ)
    (hmod : ∀ x y, dist y x < R → |g y-g x| ≤ ε) (x : G) :
    |(W ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] g) x-g x| ≤ ε := by
  have hh := MeasureTheory.dist_convolution_le (μ := μ) (x₀ := x) (z₀ := g x)
    hε hsupport hpos hmass hmg (fun y hy => by simpa only [Real.dist_eq] using hmod x y hy)
  simpa only [Real.dist_eq] using hh

/-- Positive source density supplies the denominator bound independently
    of any inverse-density consistency claim. -/
theorem convolution_density_lower_bound {G : Type*} [AddGroup G] [MeasurableSpace G]
    (μ : Measure G) (W f : G → ℝ) (c : ℝ) (x : G)
    (hpos : ∀ y, 0 ≤ W y) (hmass : ∫ y, W y ∂μ=1)
    (hf : ∀ y, c ≤ f y) (hWint : Integrable W μ)
    (hprod : Integrable (fun y => W y*f (x-y)) μ) :
    c ≤ (W ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] f) x := by
  change c ≤ ∫ y, W y*f (x-y) ∂μ
  calc
    c = (∫ y, W y ∂μ)*c := by rw [hmass, one_mul]
    _ = ∫ y, W y*c ∂μ := (integral_mul_const c W).symm
    _ ≤ ∫ y, W y*f (x-y) ∂μ := integral_mono (hWint.mul_const c) hprod
      (fun y => mul_le_mul_of_nonneg_left (hf (x-y)) (hpos y))

#print axioms uniform_convolution_error
#print axioms convolution_density_lower_bound
end KernelContinuity
