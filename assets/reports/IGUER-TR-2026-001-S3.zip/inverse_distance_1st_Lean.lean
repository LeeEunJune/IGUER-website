import Mathlib.Algebra.BigOperators.Field
import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Analysis.Calculus.Deriv.Comp
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Convert

/-!
Formal audit of the three supplied images. Lean 4.19.0 / mathlib v4.19.0.
All physical/continuum assumptions are theorem arguments, not new axioms.
No claim of convergence of the particle dynamics to a PDE is made.
-/
namespace InverseDistance
open Finset

/-- Positive-gap form of the inverse-distance weight. -/
noncomputable def weight (a b : ℝ) : ℝ := a * b / (a + b)
noncomputable def volume (L S N : ℝ) : ℝ := L * N / S

theorem inverse_distance_formula (a b : ℝ) (ha : 0 < a) (hb : 0 < b) :
    (1 / a + 1 / b)⁻¹ = weight a b := by
  unfold weight
  field_simp; ring

theorem weight_pos (a b : ℝ) (ha : 0 < a) (hb : 0 < b) :
    0 < weight a b := div_pos (mul_pos ha hb) (add_pos ha hb)

theorem weight_equal (d : ℝ) (hd : 0 < d) : weight d d = d / 2 := by
  unfold weight
  field_simp; ring

/-- Exact local defect, which replaces the informal approximately-equal step. -/
theorem weight_defect (a b : ℝ) (ha : 0 < a) (hb : 0 < b) :
    weight a b = (a + b) / 4 - (a - b)^2 / (4 * (a + b)) := by
  unfold weight
  have hab : a + b ≠ 0 := ne_of_gt (add_pos ha hb)
  field_simp; ring

theorem weight_le_mean (a b : ℝ) (ha : 0 < a) (hb : 0 < b) :
    weight a b ≤ (a + b) / 4 := by
  rw [weight_defect a b ha hb]
  have : 0 ≤ (a-b)^2 / (4 * (a+b)) := div_nonneg (sq_nonneg (a-b)) (by positivity)
  linarith

/-- Both gap lists cover one period, so each sums to L. -/
theorem sum_defect {ι : Type*} [Fintype ι] (a b : ι → ℝ) (L : ℝ)
    (ha : ∀ i, 0 < a i) (hb : ∀ i, 0 < b i)
    (hsa : ∑ i, a i = L) (hsb : ∑ i, b i = L) :
    (∑ i, weight (a i) (b i)) = L / 2 -
      ∑ i, (a i - b i)^2 / (4 * (a i + b i)) := by
  simp_rw [weight_defect _ _ (ha _) (hb _)]
  rw [sum_sub_distrib]
  congr 1
  simp_rw [add_div]
  rw [sum_add_distrib, ← sum_div, ← sum_div, hsa, hsb]
  ring

theorem total_volume {ι : Type*} [Fintype ι]
    (N : ι → ℝ) (L : ℝ) (hS : (∑ i, N i) ≠ 0) :
    (∑ i, volume L (∑ j, N j) (N i)) = L := by
  unfold volume
  rw [← sum_div, ← mul_sum]
  exact mul_div_cancel_right₀ L hS

theorem uniform_volume (n d : ℝ) (hn : 0 < n) (hd : 0 < d) :
    volume (n*d) (n * weight d d) (weight d d) = d := by
  rw [weight_equal d hd]
  unfold volume
  field_simp

/-- A periodic four-gap configuration (d,2d,d,2d). The number of
    periods can grow while the relative normalization defect persists. -/
theorem alternating_counterexample (d : ℝ) (hd : 0 < d) :
    weight d (2*d) = 2*d/3 ∧
    4 * weight d (2*d) ≠ (6*d)/2 ∧
    volume (6*d) (4 * weight d (2*d)) (weight d (2*d)) = 3*d/2 := by
  have hw : weight d (2*d) = 2*d/3 := by
    unfold weight
    field_simp; ring
  rw [hw]
  refine ⟨rfl, ?_, ?_⟩
  · nlinarith
  · unfold volume
    field_simp; ring

/-- Exact Lagrangian continuity from differentiable conserved mass. -/
theorem discrete_continuity (ρ V : ℝ → ℝ) (t r v : ℝ)
    (hρ : HasDerivAt ρ r t) (hV : HasDerivAt V v t)
    (hm : ∀ s, ρ s * V s = ρ t * V t) (hpos : 0 < V t) :
    r + ρ t / V t * v = 0 := by
  have hc : HasDerivAt (fun s => ρ s * V s) 0 t := by
    have heq : (fun s => ρ s * V s) = (fun _ => ρ t * V t) := funext hm
    rw [heq]
    exact hasDerivAt_const t _
  have he := (hρ.mul hV).unique hc
  have hv : V t ≠ 0 := ne_of_gt hpos
  field_simp
  nlinarith

/-- PDE algebra only: expansion-rate convergence and chain-rule identification
    must be established separately for a family of particle solutions. -/
theorem continuum_continuity (ρ materialρ ux ρt ρx u : ℝ)
    (hmaterial : materialρ = ρt + u * ρx)
    (hbalance : materialρ + ρ * ux = 0) :
    ρt + (ρx * u + ρ * ux) = 0 := by
  nlinarith

/-- The exact derivative of the NORMALIZED volume. -/
theorem normalized_volume_derivative (N S : ℝ → ℝ)
    (L t n' s' : ℝ) (hN : HasDerivAt N n' t)
    (hS : HasDerivAt S s' t) (hS0 : S t ≠ 0) :
    HasDerivAt (fun x => volume L (S x) (N x))
      (L * (n' * S t - N t * s') / (S t)^2) t := by
  unfold volume
  (convert (hN.const_mul L).div hS hS0 using 1; ring)

/-- Once a face-pressure force law and Newton's law are supplied,
    the finite-volume momentum balance is just algebra. -/
theorem momentum_balance (m V acceleration force pLeft pRight : ℝ)
    (_hV : V ≠ 0) (hNewton : m * acceleration = force)
    (hforce : force = pLeft - pRight) :
    (m / V) * acceleration = -(pRight - pLeft) / V := by
  rw [div_mul_eq_mul_div, hNewton, hforce]
  ring

/-- A denominator bounded away from zero turns a small weight into a small volume. -/
theorem volume_bound (L S N c : ℝ) (hL : 0 ≤ L) (hN : 0 ≤ N)
    (hc : 0 < c) (hS : c ≤ S) : volume L S N ≤ L * N / c := by
  exact div_le_div_of_nonneg_left (mul_nonneg hL hN) hc hS

theorem weight_le_left (a b : ℝ) (ha : 0 < a) (hb : 0 < b) :
    weight a b ≤ a := by
  unfold weight
  apply (div_le_iff₀ (add_pos ha hb)).2
  nlinarith

/-- Concrete epsilon-delta collision estimate. -/
theorem collision_volume_small (L S a b c ε : ℝ)
    (hL : 0 < L) (ha : 0 < a) (hb : 0 < b)
    (hc : 0 < c) (hS : c ≤ S) (_hε : 0 < ε)
    (hsmall : a < ε*c/L) : volume L S (weight a b) < ε := by
  have h1 := volume_bound L S (weight a b) c hL.le (weight_pos a b ha hb).le hc hS
  have h2 := weight_le_left a b ha hb
  have h3 : L*a < ε*c := by simpa [mul_comm] using (lt_div_iff₀ hL).1 hsmall
  have h4 : L * weight a b / c < ε := (div_lt_iff₀ hc).2 (by nlinarith)
  exact lt_of_le_of_lt h1 h4

/-- Coercive specific energy and a lower bound on all remaining energy
    give a uniform positive lower bound on particle volume.
    t is any index (e.g. times strictly before a proposed collision).
    other includes kinetic energy and every other particle's internal energy. -/
theorem energy_volume_barrier {T : Type*} (V other : T → ℝ)
    (e : ℝ → ℝ) (m E C : ℝ) (hm : 0 < m)
    (hV : ∀ t, 0 < V t)
    (hcoercive : ∀ B : ℝ, ∃ R : ℝ, 0 < R ∧ ∀ r : ℝ, R < r → B < e r)
    (hlower : ∀ t, C ≤ other t)
    (henergy : ∀ t, m * e (m / V t) + other t ≤ E) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ t, δ ≤ V t := by
  obtain ⟨R, hR, he⟩ := hcoercive ((E-C)/m)
  refine ⟨m / R, div_pos hm hR, ?_⟩
  intro t
  by_contra hn
  have hlt : V t < m / R := lt_of_not_ge hn
  have hr : R < m / V t := (lt_div_iff₀ (hV t)).2 (by
    have := (lt_div_iff₀ hR).1 hlt
    nlinarith)
  have hb := he (m / V t) hr
  have hh := (div_lt_iff₀ hm).1 hb
  have htot := henergy t
  have hlo := hlower t
  nlinarith

/-- Apply this to the volume barrier above; approaching zero is impossible. -/
theorem no_collision {T : Type*} (V : T → ℝ)
    (hbarrier : ∃ δ : ℝ, 0 < δ ∧ ∀ t, δ ≤ V t)
    (happroach : ∀ ε : ℝ, 0 < ε → ∃ t, V t < ε) : False := by
  obtain ⟨δ, hδ, hb⟩ := hbarrier
  obtain ⟨t, ht⟩ := happroach δ hδ
  exact (not_lt_of_ge (hb t)) ht

#print axioms inverse_distance_formula
#print axioms sum_defect
#print axioms alternating_counterexample
#print axioms discrete_continuity
#print axioms normalized_volume_derivative
#print axioms collision_volume_small
#print axioms energy_volume_barrier
#print axioms no_collision
end InverseDistance

namespace InverseDistance
open Finset

theorem weight_derivative (a b : ℝ → ℝ) (t a' b' : ℝ)
    (ha : HasDerivAt a a' t) (hb : HasDerivAt b b' t)
    (hab : a t + b t ≠ 0) :
    HasDerivAt (fun x => weight (a x) (b x))
      (((a' * b t + a t * b') * (a t + b t) -
        a t * b t * (a' + b')) / (a t + b t)^2) t := by
  unfold weight
  convert (ha.mul hb).div (ha.add hb) hab using 1

/-- Three particles on a circle of length 3, with positions (0,1+t,2).
    Gaps are (1+t,1-t,1). At t=0 the network volume derivative at
    particle 0 is 1/2, while u_1-u_0 = 1. All gaps are positive near 0. -/
theorem kinematic_counterexample :
    HasDerivAt (fun t : ℝ => volume 3
      (weight 1 (1+t) + weight (1+t) (1-t) + weight (1-t) 1)
      (weight 1 (1+t))) (1/2) 0 := by
  have hc : HasDerivAt (fun _ : ℝ => (1 : ℝ)) 0 0 := hasDerivAt_const 0 1
  have hp : HasDerivAt (fun t : ℝ => 1+t) 1 0 := by
    simpa using (hasDerivAt_id (0 : ℝ)).const_add 1
  have hm : HasDerivAt (fun t : ℝ => 1-t) (-1) 0 := by
    simpa using (hasDerivAt_id (0 : ℝ)).const_sub 1
  have h0 : HasDerivAt (fun t : ℝ => weight 1 (1+t)) (1/4) 0 := by
    convert weight_derivative _ _ 0 0 1 hc hp (by norm_num) using 1 ; norm_num
  have h1 : HasDerivAt (fun t : ℝ => weight (1+t) (1-t)) 0 0 := by
    convert weight_derivative _ _ 0 1 (-1) hp hm (by norm_num) using 1 ; norm_num
  have h2 : HasDerivAt (fun t : ℝ => weight (1-t) 1) (-1/4) 0 := by
    convert weight_derivative _ _ 0 (-1) 0 hm hc (by norm_num) using 1 ; norm_num
  have hs : HasDerivAt (fun t : ℝ =>
      weight 1 (1+t) + weight (1+t) (1-t) + weight (1-t) 1) 0 0 := by
    convert (h0.add h1).add h2 using 1 ; norm_num
  convert normalized_volume_derivative _ _ 3 0 (1/4) 0 h0 hs
    (by norm_num [weight]) using 1 ; norm_num [weight]

/-- Correct variational force identity along a single coordinate x.
    The thermodynamic relation dU_k/dV_k=-P_k is an explicit hypothesis. -/
theorem variational_force {ι : Type*} [Fintype ι]
    (U V : ι → ℝ → ℝ) (P v : ι → ℝ) (x : ℝ)
    (hU : ∀ i, HasDerivAt (U i) (-P i) (V i x))
    (hV : ∀ i, HasDerivAt (V i) (v i) x) :
    HasDerivAt (fun y => ∑ i, U i (V i y)) (-(∑ i, P i * v i)) x := by
  have h := HasDerivAt.sum (u := (univ : Finset ι))
    (fun i _ => (hU i).comp x (hV i))
  simpa only [neg_mul, sum_neg_distrib] using h

#print axioms kinematic_counterexample
#print axioms variational_force
end InverseDistance

namespace InverseDistance
/-- Combined network theorem: a gap cannot approach zero under the
    normalization lower bound and the coercive-energy hypotheses. -/
theorem network_no_collision {T : Type*}
    (a b S other : T → ℝ) (e : ℝ → ℝ) (L c m E C : ℝ)
    (hL : 0 < L) (hc : 0 < c) (hm : 0 < m)
    (ha : ∀ t, 0 < a t) (hb : ∀ t, 0 < b t) (hS : ∀ t, c ≤ S t)
    (he : ∀ B : ℝ, ∃ R : ℝ, 0 < R ∧ ∀ r : ℝ, R < r → B < e r)
    (hlower : ∀ t, C ≤ other t)
    (henergy : ∀ t, m * e (m / volume L (S t) (weight (a t) (b t))) + other t ≤ E)
    (hgap : ∀ ε : ℝ, 0 < ε → ∃ t, a t < ε) : False := by
  have hV : ∀ t, 0 < volume L (S t) (weight (a t) (b t)) := by
    intro t
    exact div_pos (mul_pos hL (weight_pos _ _ (ha t) (hb t))) (lt_of_lt_of_le hc (hS t))
  obtain ⟨δ, hδ, hbar⟩ := energy_volume_barrier
    (fun t => volume L (S t) (weight (a t) (b t))) other e m E C hm hV he hlower henergy
  obtain ⟨t, ht⟩ := hgap (δ*c/L) (div_pos (mul_pos hδ hc) hL)
  have hv := collision_volume_small L (S t) (a t) (b t) c δ
    hL (ha t) (hb t) hc (hS t) hδ ht
  exact (not_lt_of_ge (hbar t)) hv

#print axioms network_no_collision
end InverseDistance






