import inverse_distance_1st_Lean
import Mathlib.Analysis.Calculus.Deriv.Pow
import Mathlib.Analysis.Calculus.Deriv.Slope
import Mathlib.Topology.MetricSpace.Pseudo.Lemmas
import Mathlib.Algebra.Order.BigOperators.Group.Finset

/-!
Exact discrete identities and genuine filter limits (operator consistency).
No stability/convergence theorem for numerical solution trajectories is claimed.
Local mesh assumptions are first-order Taylor data for NORMALIZED gaps d/h.
-/
namespace InverseDistance
open Finset Filter
open scoped Topology

noncomputable def sqRatio (a b : ℝ) : ℝ := (a / (a+b))^2
noncomputable def drift (a b c d : ℝ) : ℝ :=
  sqRatio a b + sqRatio c b - sqRatio b c - sqRatio d c
noncomputable def pressureNumerator (a b c d pm p pp pb : ℝ) : ℝ :=
  sqRatio a b * (pm-p) - sqRatio d c * (pp-p) + (p-pb) * drift a b c d

/-- Exact local chain rule in the two gaps. -/
theorem weight_derivative_exact (a b : ℝ → ℝ) (t av bv : ℝ)
    (ha : HasDerivAt a av t) (hb : HasDerivAt b bv t)
    (hab : a t + b t ≠ 0) :
    HasDerivAt (fun x => weight (a x) (b x))
      (sqRatio (b t) (a t) * av + sqRatio (a t) (b t) * bv) t := by
  convert weight_derivative a b t av bv ha hb hab using 1
  simp only [sqRatio, add_comm (b t) (a t)]
  field_simp [hab]
  <;> ring

/-- Exact logarithmic growth: weighted left and right velocity slopes. -/
theorem weight_log_rate (a b av bv : ℝ) (ha : 0 < a) (hb : 0 < b) :
    (sqRatio b a * av + sqRatio a b * bv) / weight a b =
      b/(a+b) * (av/a) + a/(a+b) * (bv/b) := by
  unfold sqRatio weight
  have hab : a+b ≠ 0 := ne_of_gt (add_pos ha hb)
  have hba : b+a ≠ 0 := by linarith
  field_simp
  <;> ring

/-- Constitutive pressure is derived from U(V)=m e(m/V). -/
theorem thermodynamic_pressure (e : ℝ → ℝ) (m V ep : ℝ)
    (hV : V ≠ 0) (he : HasDerivAt e ep (m/V)) :
    HasDerivAt (fun v => m * e (m/v)) (-((m/V)^2 * ep)) V := by
  have hr := (hasDerivAt_const V m).div (hasDerivAt_id V) hV
  convert (he.comp V hr).const_mul m using 1 <;> field_simp <;> ring

/-- The global normalization produces a volume-weighted pressure subtraction. -/
theorem centered_variation {ι : Type*} [Fintype ι]
    (N P v : ι → ℝ) (L : ℝ) (hS : (∑ i, N i) ≠ 0) :
    (∑ i, P i * (L * (v i * (∑ k, N k) - N i * (∑ k, v k)) /
      (∑ k, N k)^2)) =
    L/(∑ k, N k) * ∑ i, (P i - (∑ k, P k * N k)/(∑ k, N k)) * v i := by
  have hi : ∀ i, P i * (L * (v i * (∑ k, N k) - N i * (∑ k, v k)) /
      (∑ k, N k)^2) =
      L/(∑ k, N k) * (P i * v i) -
      (L * (∑ k, v k) / (∑ k, N k)^2) * (P i * N i) := by
    intro i
    field_simp
    <;> ring
  simp_rw [hi, sub_mul]
  rw [sum_sub_distrib, ← mul_sum, ← mul_sum, sum_sub_distrib, ← mul_sum]
  field_simp
  <;> ring

/-- The exact force is a difference of corrected face stresses. -/
theorem exact_face_difference (a b c d pm p pp pb : ℝ) :
    sqRatio a b * (pm-pb) +
      (sqRatio c b - sqRatio b c) * (p-pb) - sqRatio d c * (pp-pb) =
    (sqRatio a b * (pm-pb) + sqRatio c b * (p-pb)) -
      (sqRatio b c * (p-pb) + sqRatio d c * (pp-pb)) := by ring

/-- Rearrangement exposing the potentially dangerous geometric drift. -/
theorem exact_pressure_decomposition (a b c d pm p pp pb : ℝ) :
    (sqRatio a b * (pm-pb) + sqRatio c b * (p-pb)) -
      (sqRatio b c * (p-pb) + sqRatio d c * (pp-pb)) =
      pressureNumerator a b c d pm p pp pb := by
  unfold pressureNumerator drift
  ring

/-- At equal normalized gaps, the ratio coefficient has a simple derivative. -/
theorem sqRatio_derivative (a b : ℝ → ℝ) (J av bv : ℝ) (hJ : J ≠ 0)
    (ha0 : a 0 = J) (hb0 : b 0 = J)
    (ha : HasDerivAt a av 0) (hb : HasDerivAt b bv 0) :
    HasDerivAt (fun h => sqRatio (a h) (b h)) ((av-bv)/(4*J)) 0 := by
  have hz : a 0 + b 0 ≠ 0 := by rw [ha0, hb0]; intro hz; apply hJ; linarith
  convert ((ha.div (ha.add hb) hz).pow 2) using 1
  rw [ha0, hb0]
  norm_num
  field_simp [hJ]
  <;> ring

/-- Taylor geometry: four consecutive normalized gaps have derivatives
    (-3K,-K,K,3K), with K=X_qq/2. The geometric drift is o(h). -/
theorem drift_derivative_zero (a b c d : ℝ → ℝ) (J K : ℝ) (hJ : J ≠ 0)
    (ha0 : a 0 = J) (hb0 : b 0 = J) (hc0 : c 0 = J) (hd0 : d 0 = J)
    (ha : HasDerivAt a (-3*K) 0) (hb : HasDerivAt b (-K) 0)
    (hc : HasDerivAt c K 0) (hd : HasDerivAt d (3*K) 0) :
    HasDerivAt (fun h => drift (a h) (b h) (c h) (d h)) 0 0 := by
  have h1 := sqRatio_derivative a b J (-3*K) (-K) hJ ha0 hb0 ha hb
  have h2 := sqRatio_derivative c b J K (-K) hJ hc0 hb0 hc hb
  have h3 := sqRatio_derivative b c J (-K) K hJ hb0 hc0 hb hc
  have h4 := sqRatio_derivative d c J (3*K) K hJ hd0 hc0 hd hc
  convert ((h1.add h2).sub h3).sub h4 using 1 <;> ring

/-- A derivative at zero gives a punctured-neighborhood quotient limit. -/
theorem quotient_limit (f : ℝ → ℝ) (v : ℝ)
    (hf : HasDerivAt f v 0) (hf0 : f 0 = 0) :
    Tendsto (fun h => f h / h) (𝓝[≠] 0) (𝓝 v) := by
  simpa [hf0, div_eq_mul_inv, mul_comm] using hf.tendsto_slope_zero

/-- Genuine continuum limit of the force density. No pressure-force
    consistency is assumed: it follows from the four mesh jets and the
    pressure derivatives. Only a uniform bound on p-pb is needed; pb need not converge. -/
theorem pressure_gradient_limit (a b c d pm pp pb : ℝ → ℝ)
    (J K p G : ℝ) (hJ : 0 < J)
    (ha0 : a 0 = J) (hb0 : b 0 = J) (hc0 : c 0 = J) (hd0 : d 0 = J)
    (ha : HasDerivAt a (-3*K) 0) (hb : HasDerivAt b (-K) 0)
    (hc : HasDerivAt c K 0) (hd : HasDerivAt d (3*K) 0)
    (hpm0 : pm 0 = p) (hpp0 : pp 0 = p)
    (hpm : HasDerivAt pm (-G) 0) (hpp : HasDerivAt pp G 0)
    (hpb : ∃ M : ℝ, ∀ h, |p-pb h| ≤ M) :
    Tendsto (fun h => pressureNumerator (a h) (b h) (c h) (d h)
      (pm h) p (pp h) (pb h) / (h * weight (b h) (c h)))
      (𝓝[≠] 0) (𝓝 (-G/J)) := by
  have hJn : J ≠ 0 := ne_of_gt hJ
  have hcoeff1 := sqRatio_derivative a b J (-3*K) (-K) hJn ha0 hb0 ha hb
  have hcoeff2 := sqRatio_derivative d c J (3*K) K hJn hd0 hc0 hd hc
  have hcoef1lim : Tendsto (fun h => sqRatio (a h) (b h)) (𝓝[≠] 0) (𝓝 (1/4)) := by
    convert hcoeff1.continuousAt.tendsto.mono_left nhdsWithin_le_nhds using 1
    rw [ha0, hb0]; unfold sqRatio; field_simp; ring
  have hcoef2lim : Tendsto (fun h => sqRatio (d h) (c h)) (𝓝[≠] 0) (𝓝 (1/4)) := by
    convert hcoeff2.continuousAt.tendsto.mono_left nhdsWithin_le_nhds using 1
    rw [hd0, hc0]; unfold sqRatio; field_simp; ring
  have hminus := quotient_limit (fun h => pm h-p) (-G)
    (hpm.sub_const p) (by simp [hpm0])
  have hplus := quotient_limit (fun h => pp h-p) G
    (hpp.sub_const p) (by simp [hpp0])
  have hdr := drift_derivative_zero a b c d J K hJn ha0 hb0 hc0 hd0 ha hb hc hd
  have hdr0 : drift (a 0) (b 0) (c 0) (d 0) = 0 := by
    rw [ha0, hb0, hc0, hd0]; unfold drift; ring
  have hdrlim := quotient_limit (fun h => drift (a h) (b h) (c h) (d h)) 0 hdr hdr0
  have hperturb : Tendsto (fun h => (p-pb h) * (drift (a h) (b h) (c h) (d h)/h))
      (𝓝[≠] 0) (𝓝 0) := by
    obtain ⟨M, hM⟩ := hpb
    apply (tendsto_zero_iff_abs_tendsto_zero _).mpr
    apply squeeze_zero (fun _ => abs_nonneg _) (fun h => ?_)
      (by simpa using ((tendsto_zero_iff_abs_tendsto_zero _).mp hdrlim).const_mul M)
    rw [abs_mul]
    exact mul_le_mul_of_nonneg_right (hM h) (abs_nonneg _)
  have hnum := ((hcoef1lim.mul hminus).sub (hcoef2lim.mul hplus)).add hperturb
  have hden : Tendsto (fun h => weight (b h) (c h)) (𝓝[≠] 0) (𝓝 (J/2)) := by
    have hz : b 0+c 0 ≠ 0 := by rw [hb0, hc0]; positivity
    have hw := weight_derivative b c 0 (-K) K hb hc hz
    convert hw.continuousAt.tendsto.mono_left nhdsWithin_le_nhds using 1
    rw [hb0, hc0, weight_equal J hJ]
  have hlim := hnum.div hden (by positivity : J/2 ≠ 0)
  convert hlim using 1
  · ext h
    dsimp only [Pi.div_apply, Pi.mul_apply, Pi.inv_apply]
    unfold pressureNumerator
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring
  · congr 1
    field_simp
    <;> ring

end InverseDistance


namespace InverseDistance
open Finset Filter
open scoped Topology

/-- Periodicity cancels the constant part of the edge coefficient exactly. -/
theorem global_rate_bound {ι : Type*} (s : Finset ι) (B du : ι → ℝ)
    (S smin η M : ℝ) (hsmin : 0 < smin) (hS : smin ≤ S)
    (hη : 0 ≤ η) (hsum : ∑ i ∈ s, du i = 0)
    (hB : ∀ i ∈ s, |B i - 1/2| ≤ η)
    (hTV : ∑ i ∈ s, |du i| ≤ M) :
    |(∑ i ∈ s, B i * du i) / S| ≤ η * M / smin := by
  have hSpos : 0 < S := lt_of_lt_of_le hsmin hS
  have heq : (∑ i ∈ s, (B i - 1/2) * du i) = ∑ i ∈ s, B i * du i := by
    simp_rw [sub_mul]
    rw [sum_sub_distrib, ← mul_sum, hsum]
    ring
  have hnum : |∑ i ∈ s, B i * du i| ≤ η*M := by
    rw [← heq]
    calc
      |∑ i ∈ s, (B i - 1/2) * du i| ≤ ∑ i ∈ s, |(B i - 1/2) * du i| := abs_sum_le_sum_abs _ _
      _ ≤ ∑ i ∈ s, η * |du i| := by
        apply sum_le_sum
        intro i hi
        rw [abs_mul]
        exact mul_le_mul_of_nonneg_right (hB i hi) (abs_nonneg _)
      _ = η * ∑ i ∈ s, |du i| := (mul_sum ..).symm
      _ ≤ η*M := mul_le_mul_of_nonneg_left hTV hη
  have hM : 0 ≤ M := le_trans (sum_nonneg (fun i _ => abs_nonneg (du i))) hTV
  rw [abs_div, abs_of_pos hSpos]
  exact le_trans (div_le_div_of_nonneg_right hnum hSpos.le)
    (div_le_div_of_nonneg_left (mul_nonneg hη hM) hsmin hS)

/-- An arbitrary sequence of growing periodic grids. Uniform control of the
    computable edge coefficients plus bounded velocity variation implies Sdot/S→0. -/
theorem global_rate_limit (count : ℕ → ℕ) (B du : ℕ → ℕ → ℝ)
    (S η : ℕ → ℝ) (smin M : ℝ) (hsmin : 0 < smin)
    (hS : ∀ n, smin ≤ S n) (hη : ∀ n, 0 ≤ η n)
    (hηlim : Tendsto η atTop (𝓝 0))
    (hsum : ∀ n, ∑ i ∈ range (count n), du n i = 0)
    (hB : ∀ n i, i ∈ range (count n) → |B n i - 1/2| ≤ η n)
    (hTV : ∀ n, ∑ i ∈ range (count n), |du n i| ≤ M) :
    Tendsto (fun n => (∑ i ∈ range (count n), B n i * du n i) / S n)
      atTop (𝓝 0) := by
  apply (tendsto_zero_iff_abs_tendsto_zero _).mpr
  apply squeeze_zero (fun _ => abs_nonneg _) (fun n =>
    global_rate_bound (range (count n)) (B n) (du n) (S n) smin (η n) M
      hsmin (hS n) (hη n) (hsum n) (hB n) (hTV n))
  simpa using (hηlim.mul_const M).div_const smin

/-- Consistency of the local weighted velocity slopes needs only their
    common limit; the gap ratio itself may converge to any value. -/
theorem local_expansion_limit {α : Type*} {l : Filter α}
    (w left right : α → ℝ) (θ ux : ℝ)
    (hw : Tendsto w l (𝓝 θ)) (hl : Tendsto left l (𝓝 ux))
    (hr : Tendsto right l (𝓝 ux)) :
    Tendsto (fun n => w n * left n + (1-w n) * right n) l (𝓝 ux) := by
  convert (hw.mul hl).add (((tendsto_const_nhds (x := (1:ℝ))).sub hw).mul hr) using 1
  congr 1
  ring

/-- Continuity in the continuum limit, using an already-proved global-rate
    limit and the exact discrete conservation equation. -/
theorem continuity_limit {α : Type*} {l : Filter α} [l.NeBot]
    (ρ ρdot localRate globalRate : α → ℝ) (ρ0 r0 ux : ℝ)
    (hρ : Tendsto ρ l (𝓝 ρ0)) (hr : Tendsto ρdot l (𝓝 r0))
    (ha : Tendsto localRate l (𝓝 ux)) (hg : Tendsto globalRate l (𝓝 0))
    (hm : ∀ n, ρdot n + ρ n * (localRate n - globalRate n) = 0) :
    r0 + ρ0*ux = 0 := by
  have hh := hr.add (hρ.mul (ha.sub hg))
  have hz : Tendsto (fun n => ρdot n + ρ n * (localRate n-globalRate n)) l (𝓝 0) := by
    simp_rw [hm]
    exact tendsto_const_nhds
  simpa using tendsto_nhds_unique hh hz

#print axioms weight_derivative_exact
#print axioms thermodynamic_pressure
#print axioms centered_variation
#print axioms pressure_gradient_limit
#print axioms global_rate_limit
#print axioms continuity_limit
end InverseDistance



namespace InverseDistance
open Finset Filter
open scoped Topology

/-- The exact periodic index shift; the permutation is the successor map. -/
theorem periodic_weight_rate {ι : Type*} [Fintype ι] (σ : Equiv.Perm ι)
    (α β du : ι → ℝ) :
    (∑ i, (α i * du (σ.symm i) + β i * du i)) =
      ∑ i, (β i + α (σ i)) * du i := by
  rw [sum_add_distrib]
  have hr : (∑ i, α i * du (σ.symm i)) = ∑ i, α (σ i) * du i := by
    symm
    convert Equiv.sum_comp σ (fun i => α i * du (σ.symm i)) using 1 <;> simp
  rw [hr]
  simp_rw [add_mul]
  rw [sum_add_distrib]
  ring

theorem periodic_velocity_sum {ι : Type*} [Fintype ι]
    (σ : Equiv.Perm ι) (u : ι → ℝ) : (∑ i, (u (σ i)-u i)) = 0 := by
  rw [sum_sub_distrib, Equiv.sum_comp σ]
  ring

/-- Physical secant velocity slopes converge to U_q/X_q from differentiability
    alone; no convergence of these slopes is postulated. -/
theorem sampled_velocity_slopes (X U : ℝ → ℝ) (q J G : ℝ)
    (hJ : J ≠ 0) (hX : HasDerivAt X J q) (hU : HasDerivAt U G q) :
    Tendsto (fun h => (U (q+h)-U q)/(X (q+h)-X q)) (𝓝[≠] 0) (𝓝 (G/J)) ∧
    Tendsto (fun h => (U q-U (q-h))/(X q-X (q-h))) (𝓝[≠] 0) (𝓝 (G/J)) := by
  have hxp : HasDerivAt (fun h => X (q+h)-X q) J 0 := by
    simpa using (hX.comp_of_eq 0 ((hasDerivAt_id (0:ℝ)).const_add q) (by simp)).sub_const (X q)
  have hup : HasDerivAt (fun h => U (q+h)-U q) G 0 := by
    simpa using (hU.comp_of_eq 0 ((hasDerivAt_id (0:ℝ)).const_add q) (by simp)).sub_const (U q)
  have hxm : HasDerivAt (fun h => X q-X (q-h)) J 0 := by
    simpa using (hX.comp_of_eq 0 ((hasDerivAt_id (0:ℝ)).const_sub q) (by simp)).const_sub (X q)
  have hum : HasDerivAt (fun h => U q-U (q-h)) G 0 := by
    simpa using (hU.comp_of_eq 0 ((hasDerivAt_id (0:ℝ)).const_sub q) (by simp)).const_sub (U q)
  have lp := (quotient_limit _ G hup (by simp)).div (quotient_limit _ J hxp (by simp)) hJ
  have lm := (quotient_limit _ G hum (by simp)).div (quotient_limit _ J hxm (by simp)) hJ
  constructor
  · apply lp.congr'
    filter_upwards [self_mem_nhdsWithin] with h hh
    have hn : h ≠ 0 := hh
    exact div_div_div_cancel_right₀ hn _ _
  · apply lm.congr'
    filter_upwards [self_mem_nhdsWithin] with h hh
    have hn : h ≠ 0 := hh
    exact div_div_div_cancel_right₀ hn _ _

/-- Uniform relative-gap control gives a quantitative bound for S-L/2. -/
theorem normalization_error_bound {ι : Type*} [Fintype ι]
    (a b : ι → ℝ) (L η : ℝ) (hη : 0 ≤ η)
    (ha : ∀ i, 0 < a i) (hb : ∀ i, 0 < b i)
    (hsa : ∑ i, a i = L) (hsb : ∑ i, b i = L)
    (hratio : ∀ i, (a i-b i)^2 ≤ η*(a i+b i)^2) :
    |(∑ i, weight (a i) (b i)) - L/2| ≤ η*L/2 := by
  have hd : 0 ≤ ∑ i, (a i-b i)^2/(4*(a i+b i)) :=
    sum_nonneg (fun i _ => div_nonneg (sq_nonneg _) (le_of_lt (mul_pos (by norm_num) (add_pos (ha i) (hb i)))))
  have hu : (∑ i, (a i-b i)^2/(4*(a i+b i))) ≤ η*L/2 := by
    calc
      (∑ i, (a i-b i)^2/(4*(a i+b i))) ≤ ∑ i, η*(a i+b i)/4 := by
        apply sum_le_sum
        intro i _
        apply (div_le_iff₀ (mul_pos (by norm_num) (add_pos (ha i) (hb i)))).2
        nlinarith [hratio i]
      _ = η*L/2 := by
        simp_rw [mul_add, add_div]
        rw [sum_add_distrib, ← sum_div, ← sum_div, ← mul_sum, ← mul_sum, hsa, hsb]
        ring
  rw [sum_defect a b L ha hb hsa hsb]
  have hh : L/2 - (∑ i, (a i-b i)^2/(4*(a i+b i))) - L/2 =
      -(∑ i, (a i-b i)^2/(4*(a i+b i))) := by ring
  rw [hh, abs_neg, abs_of_nonneg hd]
  exact hu

/-- Normalization limit for growing grids with vanishing relative-gap defect. -/
theorem normalization_limit (count : ℕ → ℕ)
    (a b : (n : ℕ) → Fin (count n) → ℝ) (L : ℝ) (η : ℕ → ℝ)
    (hη : ∀ n, 0 ≤ η n) (hηlim : Tendsto η atTop (𝓝 0))
    (ha : ∀ n i, 0 < a n i) (hb : ∀ n i, 0 < b n i)
    (hsa : ∀ n, ∑ i, a n i = L) (hsb : ∀ n, ∑ i, b n i = L)
    (hratio : ∀ n i, (a n i-b n i)^2 ≤ η n*(a n i+b n i)^2) :
    Tendsto (fun n => ∑ i, weight (a n i) (b n i)) atTop (𝓝 (L/2)) := by
  have hz : Tendsto (fun n => (∑ i, weight (a n i) (b n i))-L/2) atTop (𝓝 0) := by
    apply (tendsto_zero_iff_abs_tendsto_zero _).mpr
    apply squeeze_zero (fun _ => abs_nonneg _) (fun n =>
      normalization_error_bound (a n) (b n) L (η n) (hη n) (ha n) (hb n) (hsa n) (hsb n) (hratio n))
    simpa using (hηlim.mul_const L).div_const 2
  simpa using hz.add_const (L/2)

/-- Once normalized gaps converge, V/h and the equal-mass density have the
    expected limits. This is a generic-filter theorem, including h→0 and sequences. -/
theorem volume_density_limit {α : Type*} {l : Filter α}
    (a b S : α → ℝ) (L J μ : ℝ) (hL : 0 < L) (hJ : 0 < J)
    (ha : Tendsto a l (𝓝 J)) (hb : Tendsto b l (𝓝 J))
    (hS : Tendsto S l (𝓝 (L/2))) :
    Tendsto (fun n => L*weight (a n) (b n)/S n) l (𝓝 J) ∧
    Tendsto (fun n => μ*S n/(L*weight (a n) (b n))) l (𝓝 (μ/J)) := by
  have hn : Tendsto (fun n => weight (a n) (b n)) l (𝓝 (J/2)) := by
    have hh := (ha.mul hb).div (ha.add hb) (by positivity : J+J ≠ 0)
    convert hh using 1
    congr 1
    field_simp
    <;> ring
  constructor
  · convert ((tendsto_const_nhds (x := L)).mul hn).div hS (by positivity : L/2 ≠ 0) using 1
    congr 1
    field_simp
    <;> ring
  · convert ((tendsto_const_nhds (x := μ)).mul hS).div
      ((tendsto_const_nhds (x := L)).mul hn) (by positivity : L*(J/2) ≠ 0) using 1
    congr 1
    field_simp
    <;> ring

#print axioms periodic_weight_rate
#print axioms sampled_velocity_slopes
#print axioms normalization_limit
#print axioms volume_density_limit
end InverseDistance


namespace InverseDistance
open Finset Filter
open scoped Topology

/-- A Peano remainder: R(h)→0 suffices for the derivative of J+v*h+h*R(h). -/
theorem linear_remainder_derivative (R : ℝ → ℝ) (J v : ℝ)
    (hR : Tendsto R (𝓝 0) (𝓝 0)) :
    HasDerivAt (fun h => J+v*h+h*R h) v 0 := by
  apply hasDerivAt_iff_tendsto_slope_zero.mpr
  have hl : Tendsto (fun h => v+R h) (𝓝[≠] 0) (𝓝 v) := by
    simpa using (tendsto_const_nhds (x := v)).add (hR.mono_left nhdsWithin_le_nhds)
  apply hl.congr'
  filter_upwards [self_mem_nhdsWithin] with h hh
  have hn : h ≠ 0 := hh
  simp only [zero_add, mul_zero, zero_mul, add_zero, smul_eq_mul]
  field_simp
  <;> ring

noncomputable def normalizedGap (X : ℝ → ℝ) (q J k h : ℝ) : ℝ :=
  if h=0 then J else (X (q+(k+1)*h)-X (q+k*h))/h

/-- The mesh jets required by the pressure theorem are derived from a
    second-order Taylor expansion with a continuous-at-zero Peano remainder.
    This assumption is satisfied by C² position maps; no operator limit is assumed. -/
theorem normalized_gap_derivative (X R : ℝ → ℝ) (q J K k : ℝ)
    (hTaylor : ∀ s, X (q+s) = X q+J*s+K*s^2+s^2*R s)
    (hR : Tendsto R (𝓝 0) (𝓝 0)) :
    HasDerivAt (normalizedGap X q J k) ((2*k+1)*K) 0 := by
  have hp : Tendsto (fun h => R ((k+1)*h)) (𝓝 0) (𝓝 0) :=
    hR.comp (by simpa using ((tendsto_id : Tendsto (fun h : ℝ => h) (𝓝 0) (𝓝 0)).const_mul (k+1)))
  have hm : Tendsto (fun h => R (k*h)) (𝓝 0) (𝓝 0) :=
    hR.comp (by simpa using ((tendsto_id : Tendsto (fun h : ℝ => h) (𝓝 0) (𝓝 0)).const_mul k))
  have hr : Tendsto (fun h => (k+1)^2*R ((k+1)*h)-k^2*R (k*h)) (𝓝 0) (𝓝 0) := by
    simpa using (hp.const_mul ((k+1)^2)).sub (hm.const_mul (k^2))
  have hd := linear_remainder_derivative _ J ((2*k+1)*K) hr
  apply hd.congr_of_eventuallyEq
  apply Filter.Eventually.of_forall
  intro h
  by_cases hz : h=0
  · simp [normalizedGap, hz]
  · rw [normalizedGap, if_neg hz, hTaylor ((k+1)*h), hTaylor (k*h)]
    field_simp
    <;> ring

/-- A complete pressure-consistency theorem for sampled positions with
    second-order Taylor data and sampled differentiable pressure.
    G=P_q and J=X_q, so the conclusion is -P_x=-G/J. -/
theorem sampled_pressure_limit (X R P pb : ℝ → ℝ)
    (q J K G : ℝ) (hJ : 0 < J)
    (hTaylor : ∀ s, X (q+s) = X q+J*s+K*s^2+s^2*R s)
    (hR : Tendsto R (𝓝 0) (𝓝 0)) (hP : HasDerivAt P G q)
    (hpb : ∃ M : ℝ, ∀ h, |P q-pb h| ≤ M) :
    Tendsto (fun h => pressureNumerator
      (normalizedGap X q J (-2) h) (normalizedGap X q J (-1) h)
      (normalizedGap X q J 0 h) (normalizedGap X q J 1 h)
      (P (q-h)) (P q) (P (q+h)) (pb h) /
      (h * weight (normalizedGap X q J (-1) h) (normalizedGap X q J 0 h)))
      (𝓝[≠] 0) (𝓝 (-G/J)) := by
  apply pressure_gradient_limit _ _ _ _ _ _ _ J K (P q) G hJ
  · simp [normalizedGap]
  · simp [normalizedGap]
  · simp [normalizedGap]
  · simp [normalizedGap]
  · convert normalized_gap_derivative X R q J K (-2) hTaylor hR using 1 <;> ring
  · convert normalized_gap_derivative X R q J K (-1) hTaylor hR using 1 <;> ring
  · convert normalized_gap_derivative X R q J K 0 hTaylor hR using 1 <;> ring
  · convert normalized_gap_derivative X R q J K 1 hTaylor hR using 1 <;> ring
  · simp
  · simp
  · simpa using hP.comp_of_eq 0 ((hasDerivAt_id (0:ℝ)).const_sub q) (by simp)
  · simpa using hP.comp_of_eq 0 ((hasDerivAt_id (0:ℝ)).const_add q) (by simp)
  · exact hpb

#print axioms normalized_gap_derivative
#print axioms sampled_pressure_limit
end InverseDistance


namespace InverseDistance
open Finset Filter
open scoped Topology

/-- Relative gap imbalance quantitatively controls each force coefficient. -/
theorem sqRatio_error_bound (a b η : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hη : 0 ≤ η) (hr : |a-b| ≤ η*(a+b)) :
    |sqRatio a b - 1/4| ≤ 3*η/4 := by
  have hs : 0 < a+b := add_pos ha hb
  have hr0 : 0 ≤ a/(a+b) := (div_pos ha hs).le
  have hr1 : a/(a+b) ≤ 1 := (div_le_one hs).2 (by linarith)
  have he : a/(a+b)-1/2 = (a-b)/(2*(a+b)) := by field_simp; ring
  have herr : |a/(a+b)-1/2| ≤ η/2 := by
    rw [he, abs_div, abs_of_pos (by positivity : 0 < 2*(a+b))]
    apply (div_le_iff₀ (by positivity : 0 < 2*(a+b))).2
    nlinarith [hr]
  have hplus : |a/(a+b)+1/2| ≤ 3/2 := by
    rw [abs_of_nonneg (by linarith)]
    linarith
  have hid : sqRatio a b-1/4 = (a/(a+b)-1/2)*(a/(a+b)+1/2) := by
    unfold sqRatio
    ring
  rw [hid, abs_mul]
  calc
    |a/(a+b)-1/2| * |a/(a+b)+1/2| ≤ (η/2)*(3/2) :=
      mul_le_mul herr hplus (abs_nonneg _) (by linarith)
    _ = 3*η/4 := by ring

theorem edge_coefficient_bound (a b c η : ℝ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hη : 0 ≤ η)
    (hab : |a-b| ≤ η*(a+b)) (hcb : |c-b| ≤ η*(c+b)) :
    |sqRatio a b + sqRatio c b - 1/2| ≤ (3/2)*η := by
  have h1 := sqRatio_error_bound a b η ha hb hη hab
  have h2 := sqRatio_error_bound c b η hc hb hη hcb
  have he : sqRatio a b + sqRatio c b-1/2 = (sqRatio a b-1/4)+(sqRatio c b-1/4) := by ring
  rw [he]
  exact le_trans (abs_add _ _) (by linarith)

/-- A normalized pressure mean is bounded whenever the sampled pressures are. -/
theorem weighted_pressure_mean_bound {ι : Type*} [Fintype ι]
    (P N : ι → ℝ) (M : ℝ) (hN : ∀ i, 0 ≤ N i)
    (hS : 0 < ∑ i, N i) (hP : ∀ i, |P i| ≤ M) :
    |(∑ i, P i*N i)/(∑ i, N i)| ≤ M := by
  rw [abs_div, abs_of_pos hS]
  apply (div_le_iff₀ hS).2
  calc
    |∑ i, P i*N i| ≤ ∑ i, |P i*N i| := abs_sum_le_sum_abs _ _
    _ ≤ ∑ i, M*N i := by
      apply sum_le_sum
      intro i _
      rw [abs_mul, abs_of_nonneg (hN i)]
      exact mul_le_mul_of_nonneg_right (hP i) (hN i)
    _ = M * ∑ i, N i := (mul_sum ..).symm

/-- Explicit mesh-condition version of the normalization-rate limit. -/
theorem global_rate_limit_from_gaps (count : ℕ → ℕ)
    (a b c du : ℕ → ℕ → ℝ) (S η : ℕ → ℝ) (smin M : ℝ)
    (hsmin : 0 < smin) (hS : ∀ n, smin ≤ S n)
    (hη : ∀ n, 0 ≤ η n) (hηlim : Tendsto η atTop (𝓝 0))
    (ha : ∀ n i, 0 < a n i) (hb : ∀ n i, 0 < b n i) (hc : ∀ n i, 0 < c n i)
    (hab : ∀ n i, |a n i-b n i| ≤ η n*(a n i+b n i))
    (hcb : ∀ n i, |c n i-b n i| ≤ η n*(c n i+b n i))
    (hsum : ∀ n, ∑ i ∈ range (count n), du n i = 0)
    (hTV : ∀ n, ∑ i ∈ range (count n), |du n i| ≤ M) :
    Tendsto (fun n => (∑ i ∈ range (count n),
      (sqRatio (a n i) (b n i)+sqRatio (c n i) (b n i))*du n i)/S n)
      atTop (𝓝 0) := by
  apply global_rate_limit count _ du S (fun n => (3/2)*η n) smin M hsmin hS
  · intro n; exact mul_nonneg (by norm_num) (hη n)
  · simpa using hηlim.const_mul (3/2 : ℝ)
  · exact hsum
  · intro n i _
    exact edge_coefficient_bound _ _ _ _ (ha n i) (hb n i) (hc n i) (hη n) (hab n i) (hcb n i)
  · exact hTV

#print axioms edge_coefficient_bound
#print axioms weighted_pressure_mean_bound
#print axioms global_rate_limit_from_gaps
end InverseDistance

namespace InverseDistance
open Filter
open scoped Topology

/-- Local expansion rate from actual sampled X,U and Taylor regularity of X. -/
theorem sampled_expansion_limit (X R U : ℝ → ℝ) (q J K G : ℝ)
    (hJ : 0 < J) (hX : HasDerivAt X J q) (hU : HasDerivAt U G q)
    (hTaylor : ∀ s, X (q+s) = X q+J*s+K*s^2+s^2*R s)
    (hR : Tendsto R (𝓝 0) (𝓝 0)) :
    Tendsto (fun h =>
      normalizedGap X q J 0 h / (normalizedGap X q J (-1) h+normalizedGap X q J 0 h) *
        ((U q-U (q-h))/(X q-X (q-h))) +
      normalizedGap X q J (-1) h / (normalizedGap X q J (-1) h+normalizedGap X q J 0 h) *
        ((U (q+h)-U q)/(X (q+h)-X q)))
      (𝓝[≠] 0) (𝓝 (G/J)) := by
  have hl : Tendsto (normalizedGap X q J (-1)) (𝓝[≠] 0) (𝓝 J) := by
    simpa [normalizedGap] using
      (normalized_gap_derivative X R q J K (-1) hTaylor hR).continuousAt.tendsto.mono_left nhdsWithin_le_nhds
  have hr : Tendsto (normalizedGap X q J 0) (𝓝[≠] 0) (𝓝 J) := by
    simpa [normalizedGap] using
      (normalized_gap_derivative X R q J K 0 hTaylor hR).continuousAt.tendsto.mono_left nhdsWithin_le_nhds
  obtain ⟨hplus, hminus⟩ := sampled_velocity_slopes X U q J G (ne_of_gt hJ) hX hU
  have hd := hl.add hr
  have hn : J+J ≠ 0 := by positivity
  have hh := ((hr.div hd hn).mul hminus).add ((hl.div hd hn).mul hplus)
  convert hh using 1
  congr 1
  field_simp
  <;> ring

/-- The material density derivative is computed from the exact discrete law.
    Its limit is obtained, rather than assumed. -/
theorem material_density_rate_limit {α : Type*} {l : Filter α}
    (ρ localRate globalRate : α → ℝ) (ρ0 ux : ℝ)
    (hρ : Tendsto ρ l (𝓝 ρ0)) (ha : Tendsto localRate l (𝓝 ux))
    (hg : Tendsto globalRate l (𝓝 0)) :
    Tendsto (fun n => -ρ n*(localRate n-globalRate n)) l (𝓝 (-ρ0*ux)) := by
  simpa only [sub_zero, neg_mul] using (hρ.mul (ha.sub hg)).neg

#print axioms sampled_expansion_limit
#print axioms material_density_rate_limit
end InverseDistance


namespace InverseDistance
/-- Homogeneity connects normalized Taylor gaps to the physical gaps h*a. -/
theorem weight_scale (h a b : ℝ) (hh : h ≠ 0) :
    weight (h*a) (h*b) = h * weight a b := by
  unfold weight
  rw [← mul_add]
  calc
    (h*a)*(h*b)/(h*(a+b)) = (h*(h*(a*b)))/(h*(a+b)) := by congr 1; ring
    _ = h*(a*b)/(a+b) := mul_div_mul_left _ _ hh
    _ = h*(a*b/(a+b)) := by ring

theorem sqRatio_scale (h a b : ℝ) (hh : h ≠ 0) :
    sqRatio (h*a) (h*b) = sqRatio a b := by
  unfold sqRatio
  rw [← mul_add, mul_div_mul_left _ _ hh]

theorem physical_force_scale (h a b c d pm p pp pb : ℝ) (hh : h ≠ 0) :
    pressureNumerator (h*a) (h*b) (h*c) (h*d) pm p pp pb /
        weight (h*b) (h*c) =
      pressureNumerator a b c d pm p pp pb / (h*weight b c) := by
  unfold pressureNumerator drift
  simp only [sqRatio_scale h _ _ hh, weight_scale h _ _ hh]

#print axioms physical_force_scale
end InverseDistance

namespace InverseDistance
open Filter
open scoped Topology

/-- Common h-dependent shifts of all pressures leave the exact force unchanged. -/
theorem moving_center_pressure_limit (a b c d pm pc pp pb : ℝ → ℝ)
    (J K p G : ℝ) (hJ : 0 < J)
    (ha0 : a 0 = J) (hb0 : b 0 = J) (hc0 : c 0 = J) (hd0 : d 0 = J)
    (ha : HasDerivAt a (-3*K) 0) (hb : HasDerivAt b (-K) 0)
    (hc : HasDerivAt c K 0) (hd : HasDerivAt d (3*K) 0)
    (hpm0 : pm 0 = p) (hpc0 : pc 0 = p) (hpp0 : pp 0 = p)
    (hpm : HasDerivAt pm (-G) 0) (hpc : HasDerivAt pc 0 0) (hpp : HasDerivAt pp G 0)
    (hpb : ∃ M : ℝ, ∀ h, |pc h-pb h| ≤ M) :
    Tendsto (fun h => pressureNumerator (a h) (b h) (c h) (d h)
      (pm h) (pc h) (pp h) (pb h) / (h*weight (b h) (c h)))
      (𝓝[≠] 0) (𝓝 (-G/J)) := by
  have hm : HasDerivAt (fun h => pm h-pc h+p) (-G) 0 := by
    simpa using (hpm.sub hpc).add_const p
  have hp : HasDerivAt (fun h => pp h-pc h+p) G 0 := by
    simpa using (hpp.sub hpc).add_const p
  have hbound : ∃ M : ℝ, ∀ h, |p-(pb h-pc h+p)| ≤ M := by
    obtain ⟨M, hM⟩ := hpb
    refine ⟨M, fun h => ?_⟩
    have he : p-(pb h-pc h+p)=pc h-pb h := by ring
    rw [he]
    exact hM h
  have hl := pressure_gradient_limit a b c d (fun h => pm h-pc h+p)
    (fun h => pp h-pc h+p) (fun h => pb h-pc h+p) J K p G hJ
    ha0 hb0 hc0 hd0 ha hb hc hd (by simp [hpm0, hpc0]) (by simp [hpp0, hpc0]) hm hp hbound
  convert hl using 1
  ext h
  unfold pressureNumerator
  ring

noncomputable def cellDensity (L μ S a b : ℝ) : ℝ := μ*S/(L*weight a b)

theorem cellDensity_equal (L μ J : ℝ) (hL : 0 < L) (hJ : 0 < J) :
    cellDensity L μ (L/2) J J = μ/J := by
  unfold cellDensity
  rw [weight_equal J hJ]
  field_simp
  <;> ring

/-- Derivative with respect to h of the network density at a common gap J.
    The normalization jet S(0)=L/2, S'(0)=0 follows from an O(h²) defect. -/
theorem cellDensity_derivative (a b S : ℝ → ℝ) (L μ J av bv : ℝ)
    (hL : 0 < L) (hJ : 0 < J) (ha0 : a 0 = J) (hb0 : b 0 = J) (hs0 : S 0 = L/2)
    (ha : HasDerivAt a av 0) (hb : HasDerivAt b bv 0) (hs : HasDerivAt S 0 0) :
    HasDerivAt (fun h => cellDensity L μ (S h) (a h) (b h))
      (-μ*(av+bv)/(2*J^2)) 0 := by
  have hz : a 0+b 0 ≠ 0 := by rw [ha0, hb0]; positivity
  have hw := weight_derivative_exact a b 0 av bv ha hb hz
  have hden : L*weight (a 0) (b 0) ≠ 0 := by rw [ha0, hb0, weight_equal J hJ]; positivity
  convert (hs.const_mul μ).div (hw.const_mul L) hden using 1
  rw [hs0, ha0, hb0, weight_equal J hJ]
  unfold sqRatio
  have hJn : J ≠ 0 := ne_of_gt hJ
  have hLn : L ≠ 0 := ne_of_gt hL
  field_simp [hJn, hLn]
  <;> ring

/-- Barotropic pressure is evaluated at the ACTUAL network density, rather
    than imposed as an independently sampled pressure field. -/
theorem eos_pressure_limit (a b c d S pb eos : ℝ → ℝ)
    (L μ J K ep : ℝ) (hL : 0 < L) (hJ : 0 < J)
    (ha0 : a 0 = J) (hb0 : b 0 = J) (hc0 : c 0 = J) (hd0 : d 0 = J)
    (hs0 : S 0 = L/2)
    (ha : HasDerivAt a (-3*K) 0) (hb : HasDerivAt b (-K) 0)
    (hc : HasDerivAt c K 0) (hd : HasDerivAt d (3*K) 0) (hs : HasDerivAt S 0 0)
    (heos : HasDerivAt eos ep (μ/J))
    (hpb : ∃ M : ℝ, ∀ h, |eos (cellDensity L μ (S h) (b h) (c h))-pb h| ≤ M) :
    Tendsto (fun h => pressureNumerator (a h) (b h) (c h) (d h)
      (eos (cellDensity L μ (S h) (a h) (b h)))
      (eos (cellDensity L μ (S h) (b h) (c h)))
      (eos (cellDensity L μ (S h) (c h) (d h))) (pb h) /
      (h*weight (b h) (c h))) (𝓝[≠] 0) (𝓝 (2*μ*K*ep/J^3)) := by
  have hm0 : cellDensity L μ (S 0) (a 0) (b 0) = μ/J := by
    rw [hs0, ha0, hb0, cellDensity_equal L μ J hL hJ]
  have hc00 : cellDensity L μ (S 0) (b 0) (c 0) = μ/J := by
    rw [hs0, hb0, hc0, cellDensity_equal L μ J hL hJ]
  have hp0 : cellDensity L μ (S 0) (c 0) (d 0) = μ/J := by
    rw [hs0, hc0, hd0, cellDensity_equal L μ J hL hJ]
  have hdm := cellDensity_derivative a b S L μ J (-3*K) (-K) hL hJ ha0 hb0 hs0 ha hb hs
  have hdc := cellDensity_derivative b c S L μ J (-K) K hL hJ hb0 hc0 hs0 hb hc hs
  have hdp := cellDensity_derivative c d S L μ J K (3*K) hL hJ hc0 hd0 hs0 hc hd hs
  have hm := heos.comp_of_eq 0 hdm hm0.symm
  have hcc := heos.comp_of_eq 0 hdc hc00.symm
  have hp := heos.comp_of_eq 0 hdp hp0.symm
  have hl := moving_center_pressure_limit a b c d
    (fun h => eos (cellDensity L μ (S h) (a h) (b h)))
    (fun h => eos (cellDensity L μ (S h) (b h) (c h)))
    (fun h => eos (cellDensity L μ (S h) (c h) (d h))) pb
    J K (eos (μ/J)) (-2*μ*K*ep/J^2) hJ ha0 hb0 hc0 hd0 ha hb hc hd
    (congrArg eos hm0) (congrArg eos hc00) (congrArg eos hp0)
    (by convert hm using 1 <;> ring) (by convert hcc using 1 <;> ring)
    (by convert hp using 1 <;> ring) hpb
  convert hl using 1
  congr 1
  ring

#print axioms eos_pressure_limit
end InverseDistance

namespace InverseDistance
open Filter
open scoped Topology

/-- The O(h²) normalization defect implies the normalization jet used by EOS. -/
theorem normalization_quadratic_derivative (S : ℝ → ℝ) (L C : ℝ)
    (hs0 : S 0 = L/2) (hbound : ∀ h, |S h-L/2| ≤ C*h^2) :
    HasDerivAt S 0 0 := by
  have hlim : Tendsto (fun h => (S h-S 0)/h) (𝓝[≠] 0) (𝓝 0) := by
    apply (tendsto_zero_iff_abs_tendsto_zero _).mpr
    apply squeeze_zero (fun _ => abs_nonneg _) (fun h => ?_)
      (by simpa using ((tendsto_id : Tendsto (fun h : ℝ => h) (𝓝 0) (𝓝 0)).abs.const_mul C).mono_left nhdsWithin_le_nhds)
    by_cases hz : h=0
    · simp [hz]
    · rw [abs_div, hs0]
      calc
        |S h-L/2|/|h| ≤ (C*h^2)/|h| := div_le_div_of_nonneg_right (hbound h) (abs_nonneg h)
        _ = C*|h| := by
          rw [← sq_abs]
          field_simp [abs_ne_zero.mpr hz]
          rw [← sq_abs h]
          ring
  rw [hasDerivAt_iff_tendsto_slope_zero]
  simpa [div_eq_mul_inv, mul_comm] using hlim

#print axioms normalization_quadratic_derivative
end InverseDistance



