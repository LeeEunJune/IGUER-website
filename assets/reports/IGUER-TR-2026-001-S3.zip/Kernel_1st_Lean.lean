import Mathlib.Analysis.Convolution
import Mathlib.Analysis.Calculus.Deriv.Pow
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Convert
import Mathlib.Tactic.Abel

/-! Formal audit of the supplied kernel-volume model.
Physical and quadrature/regularity assumptions are theorem arguments.
No convergence of nonlinear particle trajectories is asserted. -/
namespace KernelNetwork
open Finset Filter MeasureTheory Function
open scoped Topology Convolution

noncomputable def crowd {ι : Type*} [Fintype ι] (W : ℝ → ℝ) (x : ι → ℝ) (i : ι) : ℝ :=
  ∑ j, W (x i-x j)
noncomputable def weight (n : ℝ) : ℝ := 1/n
noncomputable def virtualVolume (L S N : ℝ) : ℝ := L*N/S
noncomputable def meanPressure {ι : Type*} [Fintype ι] (P N : ι → ℝ) : ℝ :=
  (∑ i, P i*N i)/(∑ i, N i)
noncomputable def moved {ι : Type*} [DecidableEq ι] (x : ι → ℝ) (i : ι) (t : ℝ) (j : ι) : ℝ :=
  x j + if j=i then t else 0

theorem total_volume {ι : Type*} [Fintype ι] (N : ι → ℝ) (L : ℝ)
    (hS : (∑ i, N i) ≠ 0) : (∑ i, virtualVolume L (∑ j, N j) (N i)) = L := by
  unfold virtualVolume
  rw [← sum_div, ← mul_sum]
  exact mul_div_cancel_right₀ L hS

theorem thermodynamic_pressure (e : ℝ → ℝ) (m V ep : ℝ)
    (hV : V ≠ 0) (he : HasDerivAt e ep (m/V)) :
    HasDerivAt (fun v => m*e (m/v)) (-((m/V)^2*ep)) V := by
  have hr := (hasDerivAt_const V m).div (hasDerivAt_id V) hV
  convert (he.comp V hr).const_mul m using 1 <;> field_simp <;> ring

theorem inverse_density_derivative (n : ℝ → ℝ) (t v : ℝ)
    (hn : HasDerivAt n v t) (hn0 : n t ≠ 0) :
    HasDerivAt (fun x => weight (n x)) (-(weight (n t))^2*v) t := by
  unfold weight
  convert (hasDerivAt_const t (1:ℝ)).div hn hn0 using 1 <;> field_simp <;> ring

theorem normalized_volume_derivative (N S : ℝ → ℝ) (L t nv sv : ℝ)
    (hN : HasDerivAt N nv t) (hS : HasDerivAt S sv t) (hS0 : S t ≠ 0) :
    HasDerivAt (fun x => virtualVolume L (S x) (N x))
      (L*(nv*S t-N t*sv)/(S t)^2) t := by
  unfold virtualVolume
  (convert (hN.const_mul L).div hS hS0 using 1; ring)

theorem centered_variation {ι : Type*} [Fintype ι]
    (N P v : ι → ℝ) (L : ℝ) (hS : (∑ i, N i) ≠ 0) :
    (∑ i, P i*(L*(v i*(∑ k, N k)-N i*(∑ k, v k))/(∑ k, N k)^2)) =
      L/(∑ k, N k)*∑ i, (P i-meanPressure P N)*v i := by
  unfold meanPressure
  have hi : ∀ i, P i*(L*(v i*(∑ k, N k)-N i*(∑ k, v k))/(∑ k, N k)^2) =
      L/(∑ k, N k)*(P i*v i) - (L*(∑ k, v k)/(∑ k, N k)^2)*(P i*N i) := by
    intro i; field_simp; ring
  simp_rw [hi, sub_mul]
  rw [sum_sub_distrib, ← mul_sum, ← mul_sum, sum_sub_distrib, ← mul_sum]
  field_simp
  <;> ring

/-- An even differentiable kernel has odd derivative, including g(0)=0. -/
theorem even_kernel_derivative (W g : ℝ → ℝ) (hEven : ∀ t, W (-t)=W t)
    (hW : ∀ x, HasDerivAt W (g x) x) (x : ℝ) : g (-x) = -g x := by
  have hc := (hW x).comp_of_eq (-x) ((hasDerivAt_id (-x)).neg) (by simp)
  have hc' : HasDerivAt (fun t => W (-t)) (-g x) (-x) := by simpa using hc
  have he : (fun t => W (-t)) = W := funext (fun t => hEven t)
  rw [he] at hc'
  exact (hW (-x)).unique hc'

theorem even_kernel_self_derivative (W g : ℝ → ℝ) (hEven : ∀ t, W (-t)=W t)
    (hW : ∀ x, HasDerivAt W (g x) x) : g 0 = 0 := by
  have h := even_kernel_derivative W g hEven hW 0
  simp only [neg_zero] at h
  linarith

theorem moved_derivative {ι : Type*} [DecidableEq ι] (x : ι → ℝ) (i j : ι) :
    HasDerivAt (fun t => moved x i t j) (if j=i then 1 else 0) 0 := by
  by_cases h : j=i
  · simp only [moved, h, if_true]
    simpa using (hasDerivAt_id (0:ℝ)).const_add (x i)
  · simp only [moved, h, if_false, add_zero]
    exact hasDerivAt_const 0 _

/-- Differentiate the ACTUAL finite kernel sum, including its self term. -/
theorem crowd_derivative {ι : Type*} [Fintype ι] [DecidableEq ι]
    (W g : ℝ → ℝ) (x : ι → ℝ) (i k : ι)
    (hW : ∀ z, HasDerivAt W (g z) z) :
    HasDerivAt (fun t => crowd W (moved x i t) k)
      (∑ j, g (x k-x j)*((if k=i then 1 else 0)-(if j=i then 1 else 0))) 0 := by
  apply HasDerivAt.sum
  intro j _
  exact (hW (x k-x j)).comp_of_eq 0 ((moved_derivative x i k).sub (moved_derivative x i j))
    (by simp [moved])

/-- The differentiated self term is zero and the remaining derivative is sparse. -/
theorem crowd_gradient_algebra {ι : Type*} [Fintype ι] [DecidableEq ι]
    (G : ι → ι → ℝ) (i k : ι) (hdiag : ∀ j, G j j=0)
    (hodd : ∀ j k, G j k = -G k j) :
    (∑ j, G k j*((if k=i then 1 else 0)-(if j=i then 1 else 0))) =
      if k=i then ∑ j, G i j else G i k := by
  by_cases hk : k=i
  · subst k
    simp [mul_sub, sum_sub_distrib, hdiag]
  · simp [hk, mul_sub, sum_sub_distrib, hodd i k]

/-- Pair force obtained from the centered normalized variation. -/
theorem symmetric_pair_force {ι : Type*} [Fintype ι] [DecidableEq ι]
    (P N : ι → ℝ) (G : ι → ι → ℝ) (i : ι) (α c : ℝ)
    (hdiag : G i i=0) :
    α*(∑ k, (P k-c)*(-(N k)^2 * (if k=i then ∑ j, G i j else G i k))) =
      -α*∑ j, ((P i-c)*(N i)^2+(P j-c)*(N j)^2)*G i j := by
  have he : ∀ k, (P k-c)*(-(N k)^2*(if k=i then ∑ j, G i j else G i k)) =
      (if k=i then -(P i-c)*(N i)^2*(∑ j, G i j) else 0) - (P k-c)*(N k)^2*G i k := by
    intro k
    by_cases hk : k=i
    · subst k; simp [hdiag]; ring
    · simp [hk]; ring
  simp_rw [he]
  rw [sum_sub_distrib]
  simp only [sum_ite_eq', mem_univ, if_true]
  simp_rw [add_mul]
  rw [sum_add_distrib, ← mul_sum]
  ring

/-- Exact pairwise cancellation; proves total force conservation componentwise. -/
theorem pair_force_conservation {ι : Type*} [Fintype ι]
    (A : ι → ℝ) (G : ι → ι → ℝ) (α : ℝ)
    (hodd : ∀ i j, G i j = -G j i) :
    (∑ i, -α*∑ j, (A i+A j)*G i j) = 0 := by
  have hswap : (∑ i, ∑ j, (A i+A j)*G i j) = -(∑ i, ∑ j, (A i+A j)*G i j) := by
    calc
      (∑ i, ∑ j, (A i+A j)*G i j) = ∑ j, ∑ i, (A i+A j)*G i j := sum_comm
      _ = -(∑ j, ∑ i, (A j+A i)*G j i) := by
        simp only [← sum_neg_distrib]
        apply sum_congr rfl
        intro j _
        apply sum_congr rfl
        intro i _
        rw [hodd i j]
        ring
  rw [← mul_sum]
  have hz : (∑ i, ∑ j, (A i+A j)*G i j)=0 := by linarith
  rw [hz, mul_zero]

/-- The requested density-force limit is invariant under a spatially constant pressure shift. -/
theorem continuum_cancellation (f P c df dP : ℝ) (hf : f ≠ 0) :
    -(P-c)/f^2*df - (dP/f-(P-c)/f^2*df) = -dP/f := by ring

theorem force_density_cancellation (f P c df dP : ℝ) (hf : f ≠ 0) :
    -((P-c)/f*df + f*(dP/f-(P-c)/f^2*df)) = -dP := by
  field_simp
  <;> ring

/-- Original assumptions alone permit the constant kernel: every discrete force vanishes. -/
theorem constant_kernel_counterexample {ι : Type*} [Fintype ι]
    (A : ι → ℝ) (α : ℝ) (i : ι) : (-α*∑ j, (A i+A j)*(0:ℝ))=0 := by simp

end KernelNetwork


namespace KernelNetwork
open Filter MeasureTheory Function
open scoped Topology Convolution

section VectorAlgebra
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

theorem vector_pressure_cancellation (f P : ℝ) (df dP : E) (hf : f ≠ 0) :
    -((P/f) • df + f • ((1/f) • dP - (P/f^2) • df)) = -dP := by
  have h1 : f*(1/f)=1 := by field_simp
  have h2 : f*(P/f^2)=P/f := by field_simp; ring
  rw [smul_sub, smul_smul, smul_smul, h1, h2, one_smul]
  congr 1
  abel

theorem vector_constant_pressure_cancellation (f : ℝ) (df : E) (hf : f ≠ 0) :
    (1/f) • df + f • (-(1/f^2) • df) = 0 := by
  have h1 : f*(-(1/f^2)) = -(1/f) := by field_simp; ring
  rw [smul_smul, h1, neg_smul, add_neg_cancel]

/-- The algebraic continuum limit. A bounded global pressure mean need not converge. -/
theorem force_density_limit {I : Type*} {l : Filter I}
    (r P c : I → ℝ) (B CP C0 : I → E) (f p : ℝ) (df dp : E) (hf : f ≠ 0)
    (hr : Tendsto r l (𝓝 f)) (hP : Tendsto P l (𝓝 p))
    (hB : Tendsto B l (𝓝 df))
    (hCP : Tendsto CP l (𝓝 ((1/f) • dp-(p/f^2) • df)))
    (hC0 : Tendsto C0 l (𝓝 (-(1/f^2) • df)))
    (hc : IsBoundedUnder (· ≤ ·) l (fun i => ‖c i‖)) :
    Tendsto (fun i => -((P i/r i) • B i+r i • CP i)+
      c i • ((1/r i) • B i+r i • C0 i)) l (𝓝 (-dp)) := by
  have hbase := ((hP.div hr hf).smul hB).add (hr.smul hCP)
  have hzero : Tendsto (fun i => (1/r i) • B i+r i • C0 i) l (𝓝 0) := by
    convert (((tendsto_const_nhds (x := (1:ℝ))).div hr hf).smul hB).add (hr.smul hC0) using 1
    exact (vector_constant_pressure_cancellation f df hf).symm ▸ rfl
  have hmean := hc.smul_tendsto_zero hzero
  have hh := hbase.neg.add hmean
  simpa only [vector_pressure_cancellation f p df dp hf, add_zero] using hh

end VectorAlgebra

/-- Relative error conditions for the particle-to-integral replacement are
    explicit independent quadrature assumptions, not a vague 'many particles'. -/
theorem transfer_consistency {I E : Type*} [NormedAddCommGroup E] {l : Filter I}
    (discrete continuum : I → E) (v : E)
    (hc : Tendsto continuum l (𝓝 v))
    (he : Tendsto (fun i => discrete i-continuum i) l (𝓝 0)) :
    Tendsto discrete l (𝓝 v) := by
  simpa only [sub_add_cancel, zero_add] using he.add hc

section ApproximateIdentity
variable {G E I : Type*} [SeminormedAddCommGroup G] [MeasurableSpace G]
  [BorelSpace G] [SecondCountableTopology G]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
  {μ : Measure G} [μ.IsAddLeftInvariant] [SFinite μ] {l : Filter I}

/-- Actual integral approximate-identity theorem, valid in any Euclidean dimension.
    The field may vary with h, which is needed for P_h f/(W_h*f)^2. -/
theorem approximate_identity_limit (φ : I → G → ℝ) (g : I → G → E)
    (x : G) (v : E)
    (hpos : ∀ᶠ i in l, ∀ y, 0 ≤ φ i y)
    (hmass : ∀ᶠ i in l, ∫ y, φ i y ∂μ = 1)
    (hsupport : Tendsto (fun i => support (φ i)) l (𝓝 0).smallSets)
    (hmg : ∀ᶠ i in l, AEStronglyMeasurable (g i) μ)
    (hlocal : Tendsto (uncurry g) (l ×ˢ 𝓝 x) (𝓝 v)) :
    Tendsto (fun i => (φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] g i) x) l (𝓝 v) := by
  exact MeasureTheory.convolution_tendsto_right hpos hmass hsupport hmg hlocal tendsto_const_nhds

/-- Kernel integral force limit, including h-dependent pressure and all global
    normalization pressure offsets. Gradient-field convergence is a local C¹
    consistency assumption and the convolutions are genuine measure integrals. -/
theorem integral_force_limit (φ : I → G → ℝ) (Df GP G0 : I → G → E)
    (r P c : I → ℝ) (x : G) (f p : ℝ) (df dp : E) (hf : f ≠ 0)
    (hpos : ∀ᶠ i in l, ∀ y, 0 ≤ φ i y)
    (hmass : ∀ᶠ i in l, ∫ y, φ i y ∂μ = 1)
    (hsupport : Tendsto (fun i => support (φ i)) l (𝓝 0).smallSets)
    (hmgf : ∀ᶠ i in l, AEStronglyMeasurable (Df i) μ)
    (hmgP : ∀ᶠ i in l, AEStronglyMeasurable (GP i) μ)
    (hmg0 : ∀ᶠ i in l, AEStronglyMeasurable (G0 i) μ)
    (hlocalf : Tendsto (uncurry Df) (l ×ˢ 𝓝 x) (𝓝 df))
    (hlocalP : Tendsto (uncurry GP) (l ×ˢ 𝓝 x) (𝓝 ((1/f) • dp-(p/f^2) • df)))
    (hlocal0 : Tendsto (uncurry G0) (l ×ˢ 𝓝 x) (𝓝 (-(1/f^2) • df)))
    (hr : Tendsto r l (𝓝 f)) (hP : Tendsto P l (𝓝 p))
    (hc : IsBoundedUnder (· ≤ ·) l (fun i => ‖c i‖)) :
    Tendsto (fun i =>
      -((P i/r i) • ((φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] Df i) x)+
        r i • ((φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] GP i) x))+
      c i • ((1/r i) • ((φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] Df i) x)+
        r i • ((φ i ⋆[ContinuousLinearMap.lsmul ℝ ℝ, μ] G0 i) x))) l (𝓝 (-dp)) := by
  exact force_density_limit r P c _ _ _ f p df dp hf hr hP
    (approximate_identity_limit φ Df x df hpos hmass hsupport hmgf hlocalf)
    (approximate_identity_limit φ GP x _ hpos hmass hsupport hmgP hlocalP)
    (approximate_identity_limit φ G0 x _ hpos hmass hsupport hmg0 hlocal0) hc

end ApproximateIdentity

/-- One-dimensional differentiation under the integral is verified under
    explicit sufficient compact-support and C¹ conditions. Local cutoffs allow
    its use with periodic fields when the kernel support is small. -/
theorem convolution_derivative (W g : ℝ → ℝ)
    (hW : LocallyIntegrable W) (hcompact : HasCompactSupport g) (hg : ContDiff ℝ 1 g)
    (x : ℝ) :
    HasDerivAt (W ⋆ g) ((W ⋆ deriv g) x) x := by
  exact hcompact.hasDerivAt_convolution_right (ContinuousLinearMap.lsmul ℝ ℝ) hW hg x

/-- Normalized empirical kernel sums have n-dependent crowding scale n*r. -/
theorem pair_rescaling_identity (n ri rj pi pj c G : ℝ)
    (hn : n ≠ 0) (hi : ri ≠ 0) (hj : rj ≠ 0) :
    (((pi-c)*(1/(n*ri))^2+(pj-c)*(1/(n*rj))^2)*G)/(1/(n*ri)) =
      (1/n)*((pi-c)/ri+ri*(pj-c)/rj^2)*G := by
  field_simp
  <;> ring

/-- A precise n-scaling identity also clarifies fixed total mass M. -/
theorem density_scaling (n r α M : ℝ) (hn : n ≠ 0) (hr : r ≠ 0) (hα : α ≠ 0) :
    (M/n)/(α/(n*r)) = M*r/α := by field_simp; ring

#print axioms total_volume
#print axioms thermodynamic_pressure
#print axioms crowd_derivative
#print axioms even_kernel_derivative
#print axioms symmetric_pair_force
#print axioms pair_force_conservation
#print axioms integral_force_limit
#print axioms convolution_derivative
#print axioms pair_rescaling_identity
end KernelNetwork


namespace KernelNetwork
open Finset Filter MeasureTheory
open scoped Topology

/-- Differentiating the continuum pressure integrand before taking any limit. -/
theorem pressure_integrand_derivative (P f r : ℝ → ℝ) (x p' f' r' : ℝ)
    (hP : HasDerivAt P p' x) (hf : HasDerivAt f f' x) (hr : HasDerivAt r r' x)
    (hr0 : r x ≠ 0) :
    HasDerivAt (fun y => P y*f y/(r y)^2)
      ((p'*f x+P x*f')/(r x)^2-2*P x*f x*r'/(r x)^3) x := by
  convert (hP.mul hf).div (hr.pow 2) (pow_ne_zero 2 hr0) using 1 <;> field_simp [hr0] <;> ring

theorem reciprocal_integrand_derivative (f r : ℝ → ℝ) (x f' r' : ℝ)
    (hf : HasDerivAt f f' x) (hr : HasDerivAt r r' x) (hr0 : r x ≠ 0) :
    HasDerivAt (fun y => f y/(r y)^2)
      (f'/(r x)^2-2*f x*r'/(r x)^3) x := by
  convert hf.div (hr.pow 2) (pow_ne_zero 2 hr0) using 1 <;> field_simp [hr0] <;> ring

/-- C¹ convergence yields the pressure-integrand derivative limit; this does
    not assume the final force limit. Works for gradient vectors in any dimension. -/
theorem integrand_gradient_limits {I E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {l : Filter I} (r f P : I → ℝ) (dr df dP : I → E) (f0 p0 : ℝ) (df0 dp0 : E)
    (hf0 : f0 ≠ 0) (hr : Tendsto r l (𝓝 f0)) (hf : Tendsto f l (𝓝 f0))
    (hP : Tendsto P l (𝓝 p0)) (hdr : Tendsto dr l (𝓝 df0))
    (hdf : Tendsto df l (𝓝 df0)) (hdP : Tendsto dP l (𝓝 dp0)) :
    Tendsto (fun i => (f i/(r i)^2) • dP i+(P i/(r i)^2) • df i-
      (2*P i*f i/(r i)^3) • dr i) l (𝓝 ((1/f0) • dp0-(p0/f0^2) • df0)) ∧
    Tendsto (fun i => (1/(r i)^2) • df i-(2*f i/(r i)^3) • dr i)
      l (𝓝 (-(1/f0^2) • df0)) := by
  have h2 : f0/f0^2=1/f0 := by field_simp; ring
  have h3 : 2*p0*f0/f0^3=p0/f0^2+p0/f0^2 := by field_simp; ring
  have h4 : 2*f0/f0^3=1/f0^2+1/f0^2 := by field_simp; ring
  have hcp := (((tendsto_const_nhds (x := (2:ℝ))).mul hP).mul hf).div (hr.pow 3) (pow_ne_zero 3 hf0)
  have hc0 := ((tendsto_const_nhds (x := (2:ℝ))).mul hf).div (hr.pow 3) (pow_ne_zero 3 hf0)
  constructor
  · have hh := (((hf.div (hr.pow 2) (pow_ne_zero 2 hf0)).smul hdP).add
      ((hP.div (hr.pow 2) (pow_ne_zero 2 hf0)).smul hdf)).sub
      (hcp.smul hdr)
    convert hh using 1
    congr 1
    rw [h2, h3, add_smul]
    abel
  · have hh := (((tendsto_const_nhds (x := (1:ℝ))).div (hr.pow 2) (pow_ne_zero 2 hf0)).smul hdf).sub
      (hc0.smul hdr)
    convert hh using 1
    congr 1
    rw [h4, add_smul, neg_smul]
    abel

/-- Relative crowding error gives an explicit normalization error. -/
theorem relative_reciprocal_bound (f r η : ℝ) (hf : 0 < f) (hr : 0 < r)
    (hη : 0 ≤ η) (hη1 : η < 1) (he : |r-f| ≤ η*f) :
    |f/r-1| ≤ η/(1-η) := by
  have hden : 0 < 1-η := by linarith
  have hrlo : (1-η)*f ≤ r := by have := (abs_le.mp he).1; nlinarith
  have hid : f/r-1=(f-r)/r := by field_simp
  rw [hid, abs_div, abs_of_pos hr, abs_sub_comm]
  calc
    |r-f|/r ≤ η*f/r := div_le_div_of_nonneg_right he hr.le
    _ ≤ η/(1-η) := by
      apply (div_le_iff₀ hr).2
      rw [div_mul_eq_mul_div]
      apply (le_div_iff₀ hden).2
      have hh := mul_le_mul_of_nonneg_left hrlo hη
      nlinarith

/-- Finite-domain normalization is an actual measure integral. -/
theorem integral_normalization_bound {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (f r : Ω → ℝ) (η : ℝ)
    (hf : ∀ x, 0 < f x) (hr : ∀ x, 0 < r x) (hη : 0 ≤ η) (hη1 : η < 1)
    (he : ∀ x, |r x-f x| ≤ η*f x) (hi : Integrable (fun x => f x/r x) μ) :
    |(∫ x, f x/r x ∂μ)-μ.real Set.univ| ≤ (η/(1-η))*μ.real Set.univ := by
  have hh : (∫ x, f x/r x ∂μ)-μ.real Set.univ = ∫ x, (f x/r x-1) ∂μ := by
    rw [integral_sub hi (integrable_const (1:ℝ))]
    simp
  rw [hh, ← Real.norm_eq_abs]
  exact norm_integral_le_of_norm_le_const (Filter.Eventually.of_forall fun x => by
    simpa only [Real.norm_eq_abs] using relative_reciprocal_bound (f x) (r x) η (hf x) (hr x) hη hη1 (he x))

theorem normalization_limit {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (f : Ω → ℝ) (r : ℕ → Ω → ℝ) (η : ℕ → ℝ)
    (hf : ∀ x, 0 < f x) (hr : ∀ n x, 0 < r n x)
    (hη : ∀ n, 0 ≤ η n) (hη1 : ∀ n, η n < 1)
    (he : ∀ n x, |r n x-f x| ≤ η n*f x)
    (hi : ∀ n, Integrable (fun x => f x/r n x) μ)
    (hηlim : Tendsto η atTop (𝓝 0)) :
    Tendsto (fun n => ∫ x, f x/r n x ∂μ) atTop (𝓝 (μ.real Set.univ)) := by
  have hz : Tendsto (fun n => (∫ x, f x/r n x ∂μ)-μ.real Set.univ) atTop (𝓝 0) := by
    apply (tendsto_zero_iff_abs_tendsto_zero _).mpr
    apply squeeze_zero (fun _ => abs_nonneg _) (fun n =>
      integral_normalization_bound μ f (r n) (η n) hf (hr n) (hη n) (hη1 n) (he n) (hi n))
    simpa using (hηlim.div ((tendsto_const_nhds (x := (1:ℝ))).sub hηlim) (by norm_num)).mul_const (μ.real Set.univ)
  simpa using hz.add_const (μ.real Set.univ)

#print axioms pressure_integrand_derivative
#print axioms integrand_gradient_limits
#print axioms normalization_limit
end KernelNetwork


namespace KernelNetwork
open Finset Filter MeasureTheory
open scoped Topology

/-- Quantization gives a concrete particle quadrature bound. For an equal-mass
    partition and its cell-sample map T, integral(g∘T) is the empirical average.
    The probability measure here is f(x)dx, not Lebesgue volume. -/
theorem transport_quadrature_bound {Ω E : Type*} [PseudoMetricSpace Ω] [MeasurableSpace Ω]
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (T : Ω → Ω) (g : Ω → E)
    (K δ : ℝ) (hK : 0 ≤ K) (hg : Integrable g μ) (hTg : Integrable (fun x => g (T x)) μ)
    (hdisplacement : ∀ x, dist (T x) x ≤ δ)
    (hLip : ∀ x y, ‖g x-g y‖ ≤ K*dist x y) :
    ‖(∫ x, g (T x) ∂μ)-(∫ x, g x ∂μ)‖ ≤ K*δ := by
  rw [← integral_sub hTg hg]
  have hh : ∀ᵐ x ∂μ, ‖g (T x)-g x‖ ≤ K*δ := Filter.Eventually.of_forall fun x =>
    (hLip (T x) x).trans (mul_le_mul_of_nonneg_left (hdisplacement x) hK)
  simpa using norm_integral_le_of_norm_le_const hh

/-- Any n,h coupling satisfying the explicit quadrature bound can be used.
    In particular, convergence of each coefficient integral transfers to its
    particle average when K_n*δ_n→0. -/
theorem quadrature_limit {E : Type*} [NormedAddCommGroup E]
    (empirical integral : ℕ → E) (K δ : ℕ → ℝ) (v : E)
    (hbound : ∀ n, ‖empirical n-integral n‖ ≤ K n*δ n)
    (hsmall : Tendsto (fun n => K n*δ n) atTop (𝓝 0))
    (hi : Tendsto integral atTop (𝓝 v)) :
    Tendsto empirical atTop (𝓝 v) := by
  have he : Tendsto (fun n => empirical n-integral n) atTop (𝓝 0) := by
    apply tendsto_zero_iff_norm_tendsto_zero.mpr
    exact squeeze_zero (fun _ => norm_nonneg _) hbound hsmall
  exact transfer_consistency empirical integral v hi he

/-- If the kernel width is below every pair distance, only the self term
    remains. Equal weights imply uniform virtual volumes, even on nonuniform points. -/
theorem self_only_volume (L n w : ℝ) (hn : n ≠ 0) (hw : w ≠ 0) :
    virtualVolume L (n*w) w = L/n := by
  unfold virtualVolume
  field_simp
  <;> ring

theorem newton_force_density (m V a F : ℝ) (hNewton : m*a=F) :
    (m/V)*a=F/V := by rw [div_mul_eq_mul_div, hNewton]

#print axioms transport_quadrature_bound
#print axioms quadrature_limit
#print axioms self_only_volume
end KernelNetwork


namespace KernelNetwork
open Filter MeasureTheory Function
open scoped Topology Convolution

/-- The C¹ approximate-identity limit is derived for actual convolutions in
    the explicit 1D compact-support setting; the derivative limit is not assumed. -/
theorem smoothing_C1_limit {I : Type*} {l : Filter I}
    (φ : I → ℝ → ℝ) (f : ℝ → ℝ) (x : ℝ)
    (hpos : ∀ᶠ i in l, ∀ y, 0 ≤ φ i y)
    (hmass : ∀ᶠ i in l, ∫ y, φ i y = 1)
    (hsupport : Tendsto (fun i => support (φ i)) l (𝓝 0).smallSets)
    (hW : ∀ i, LocallyIntegrable (φ i))
    (hcompact : HasCompactSupport f) (hf : ContDiff ℝ 1 f) :
    Tendsto (fun i => (φ i ⋆ f) x) l (𝓝 (f x)) ∧
    Tendsto (fun i => deriv (φ i ⋆ f) x) l (𝓝 (deriv f x)) := by
  have hlocal : Tendsto (uncurry (fun _ : I => f)) (l ×ˢ 𝓝 x) (𝓝 (f x)) :=
    hf.continuous.continuousAt.tendsto.comp tendsto_snd
  have hdf := hf.continuous_deriv (by norm_num : (1:WithTop ℕ∞) ≤ 1)
  have hlocald : Tendsto (uncurry (fun _ : I => deriv f)) (l ×ˢ 𝓝 x) (𝓝 (deriv f x)) :=
    hdf.continuousAt.tendsto.comp tendsto_snd
  constructor
  · exact approximate_identity_limit φ (fun _ => f) x (f x) hpos hmass hsupport
      (Filter.Eventually.of_forall fun _ => hf.continuous.aestronglyMeasurable) hlocal
  · have hh := approximate_identity_limit φ (fun _ => deriv f) x (deriv f x) hpos hmass hsupport
      (Filter.Eventually.of_forall fun _ => hdf.aestronglyMeasurable) hlocald
    apply hh.congr'
    exact Filter.Eventually.of_forall fun i => (convolution_derivative (φ i) f (hW i) hcompact hf x).deriv.symm

#print axioms smoothing_C1_limit
end KernelNetwork
